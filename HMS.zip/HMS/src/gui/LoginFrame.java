/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;
import gui.admin.AdminDashboard;
import gui.manager.ManagerDashboard;
import service.AuthenticationService;
import service.AuthenticationService.AuthResult;

import javax.swing.*;
import java.awt.*;

/**
 *
 * @author dhanj
 */
public class LoginFrame extends JFrame {

    private final JTextField usernameField = new JTextField(18);
    private final JPasswordField passwordField = new JPasswordField(18);
    private final AuthenticationService authService = new AuthenticationService();

    public LoginFrame() {
        setTitle("APU Medical Centre HMS - Login");
        setSize(420, 280);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("APU Medical Centre", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 1; gbc.gridx = 0;
        panel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        panel.add(usernameField, gbc);

        gbc.gridy = 2; gbc.gridx = 0;
        panel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        panel.add(passwordField, gbc);

        JCheckBox showPasswordCheckbox = new JCheckBox("Show Password");
        gbc.gridy = 3; gbc.gridx = 1;
        panel.add(showPasswordCheckbox, gbc);

        JButton loginButton = new JButton("Login");
        gbc.gridy = 4; gbc.gridx = 0; gbc.gridwidth = 2;
        panel.add(loginButton, gbc);

        JLabel hint = new JLabel("<html><i>Demo admin account: admin1 / admin123</i></html>", SwingConstants.CENTER);
        hint.setForeground(Color.GRAY);
        gbc.gridy = 5;
        panel.add(hint, gbc);

        add(panel);

        showPasswordCheckbox.addActionListener(e -> {
            if (showPasswordCheckbox.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('*');
            }
        });

        loginButton.addActionListener(e -> handleLogin());
        passwordField.addActionListener(e -> handleLogin());
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and password.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        AuthResult result = authService.authenticate(username, password);
        if (!result.success) {
            JOptionPane.showMessageDialog(this, result.message, "Login Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        switch (result.role.toUpperCase()) {
            case "ADMIN":
                dispose();
                new AdminDashboard(result.username).setVisible(true);
                break;
            case "MEDICAL_MANAGER":
                dispose();
                new ManagerDashboard(result.username).setVisible(true);
                break;
            case "DOCTOR":
            case "PATIENT":
                JOptionPane.showMessageDialog(this,
                        result.role + " dashboard is implemented by another team member's module.",
                        "Login Successful", JOptionPane.INFORMATION_MESSAGE);
                break;
            default:
                JOptionPane.showMessageDialog(this, "Unknown role.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
