package gui.manager;

import gui.LoginFrame;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import java.awt.BorderLayout;
import java.awt.Font;

/**
 * Main window for a signed-in Medical Manager.
 *
 * The window is opened by the login screen once the account has been
 * checked, and it is given the username so the manager's own record can be
 * loaded and shown.
 *
 * Each responsibility of the role sits on its own tab, which keeps every
 * task one click away and matches how the rest of the system presents a
 * dashboard.
 */
public class ManagerDashboard extends JFrame {

    private final ReportsPanel reportsPanel = new ReportsPanel();

    public ManagerDashboard(String username) {
        setTitle("APU Medical Centre HMS - Medical Manager Dashboard");
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel welcome = new JLabel("Welcome, " + username + " (Medical Manager)");
        welcome.setFont(new Font("SansSerif", Font.BOLD, 14));

        JButton logoutButton = new JButton("Logout");

        topBar.add(welcome, BorderLayout.WEST);
        topBar.add(logoutButton, BorderLayout.EAST);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("My Profile", new ProfilePanel(username));
        tabs.addTab("Departments", new DepartmentPanel());
        tabs.addTab("Doctor Schedules", new DoctorSchedulePanel());
        tabs.addTab("Assessment Types", new AssessmentTypePanel());
        tabs.addTab("Reports", reportsPanel);

        // The reports are worked out when the tab is opened so they always
        // show what is currently stored.
        tabs.addChangeListener(e -> {
            if (tabs.getSelectedComponent() == reportsPanel) {
                reportsPanel.refreshReports();
            }
        });

        setLayout(new BorderLayout());
        add(topBar, BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);

        logoutButton.addActionListener(e -> handleLogout());
    }

    private void handleLogout() {
        int choice = JOptionPane.showConfirmDialog(this,
                "Log out and return to the login screen?",
                "Confirm Logout", JOptionPane.YES_NO_OPTION);

        if (choice == JOptionPane.YES_OPTION) {
            dispose();
            new LoginFrame().setVisible(true);
        }
    }
}
