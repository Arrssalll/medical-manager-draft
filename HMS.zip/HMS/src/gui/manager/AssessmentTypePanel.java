package gui.manager;

import model.AssessmentType;
import service.AssessmentTypeService;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;

/**
 * Screen for managing the assessment and check-up types that doctors choose
 * from while recording a consultation.
 *
 * This screen only maintains the list of types. Recording an actual
 * assessment against a patient belongs to the Doctor part of the system.
 */
public class AssessmentTypePanel extends JPanel {

    private final AssessmentTypeService assessmentTypeService = new AssessmentTypeService();

    private final DefaultTableModel tableModel =
            new DefaultTableModel(new String[]{"Type ID", "Name", "Description", "Status"}, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

    private final JTable typeTable = new JTable(tableModel);
    private final JTextField idField = new JTextField(10);
    private final JTextField nameField = new JTextField(18);
    private final JTextField descriptionField = new JTextField(28);
    private final JComboBox<String> statusBox =
            new JComboBox<>(new String[]{AssessmentType.STATUS_ACTIVE, AssessmentType.STATUS_INACTIVE});

    public AssessmentTypePanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel heading = new JLabel("Assessment Types");
        heading.setFont(heading.getFont().deriveFont(Font.BOLD, 18f));
        add(heading, BorderLayout.NORTH);

        typeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        typeTable.getSelectionModel().addListSelectionListener(e -> copySelectionToForm());
        add(new JScrollPane(typeTable), BorderLayout.CENTER);

        add(buildForm(), BorderLayout.SOUTH);

        idField.setEditable(false);
        reloadTable();
    }

    private JPanel buildForm() {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Assessment type details"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        form.add(new JLabel("Type ID:"), gbc);
        gbc.gridx = 1;
        form.add(idField, gbc);

        gbc.gridx = 2;
        form.add(new JLabel("Status:"), gbc);
        gbc.gridx = 3;
        form.add(statusBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        form.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1;
        form.add(nameField, gbc);

        gbc.gridx = 2;
        form.add(new JLabel("Description:"), gbc);
        gbc.gridx = 3;
        form.add(descriptionField, gbc);

        JPanel buttons = new JPanel();
        JButton addButton = new JButton("Add");
        JButton updateButton = new JButton("Update");
        JButton findButton = new JButton("Find by ID");
        JButton refreshButton = new JButton("Refresh");
        JButton clearButton = new JButton("Clear");

        addButton.addActionListener(e -> addAssessmentType());
        updateButton.addActionListener(e -> updateAssessmentType());
        findButton.addActionListener(e -> findAssessmentType());
        refreshButton.addActionListener(e -> reloadTable());
        clearButton.addActionListener(e -> clearForm());

        buttons.add(addButton);
        buttons.add(updateButton);
        buttons.add(findButton);
        buttons.add(refreshButton);
        buttons.add(clearButton);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 4;
        form.add(buttons, gbc);

        return form;
    }

    public final void reloadTable() {
        tableModel.setRowCount(0);
        try {
            List<AssessmentType> types = assessmentTypeService.getAllAssessmentTypes();
            for (AssessmentType type : types) {
                tableModel.addRow(new Object[]{
                        type.getAssessmentTypeID(),
                        type.getAssessmentName(),
                        type.getDescription(),
                        type.getStatus()
                });
            }
        } catch (RuntimeException e) {
            showError("The assessment types could not be loaded.\n" + e.getMessage());
        }
    }

    private void addAssessmentType() {
        if (isBlank(nameField.getText()) || isBlank(descriptionField.getText())) {
            showWarning("Please fill in all required fields.");
            return;
        }

        try {
            AssessmentType created = assessmentTypeService.addAssessmentType(
                    nameField.getText(), descriptionField.getText());
            reloadTable();
            clearForm();
            showInformation("Assessment type " + created.getAssessmentTypeID() + " has been added.");
        } catch (IllegalArgumentException | IllegalStateException e) {
            showWarning(e.getMessage());
        } catch (RuntimeException e) {
            showError("The assessment type could not be saved.\n" + e.getMessage());
        }
    }

    private void updateAssessmentType() {
        if (isBlank(idField.getText())) {
            showWarning("Please select the assessment type you want to update.");
            return;
        }
        if (isBlank(nameField.getText()) || isBlank(descriptionField.getText())) {
            showWarning("Please fill in all required fields.");
            return;
        }

        try {
            assessmentTypeService.updateAssessmentType(
                    idField.getText(),
                    nameField.getText(),
                    descriptionField.getText(),
                    String.valueOf(statusBox.getSelectedItem()));
            reloadTable();
            showInformation("Assessment type " + idField.getText().trim() + " has been updated.");
        } catch (IllegalArgumentException | IllegalStateException e) {
            showWarning(e.getMessage());
        } catch (RuntimeException e) {
            showError("The changes could not be saved.\n" + e.getMessage());
        }
    }

    private void findAssessmentType() {
        String wanted = JOptionPane.showInputDialog(this, "Enter the assessment type ID to find:");
        if (wanted == null || isBlank(wanted)) {
            return;
        }

        try {
            AssessmentType found = assessmentTypeService.findAssessmentTypeById(wanted);
            if (found == null) {
                showWarning("Record not found.");
                return;
            }
            selectRowWithId(found.getAssessmentTypeID());
        } catch (IllegalArgumentException e) {
            showWarning(e.getMessage());
        } catch (RuntimeException e) {
            showError("The search could not be completed.\n" + e.getMessage());
        }
    }

    private void selectRowWithId(String typeId) {
        for (int row = 0; row < tableModel.getRowCount(); row++) {
            if (typeId.equalsIgnoreCase(String.valueOf(tableModel.getValueAt(row, 0)))) {
                typeTable.setRowSelectionInterval(row, row);
                typeTable.scrollRectToVisible(typeTable.getCellRect(row, 0, true));
                return;
            }
        }
    }

    private void copySelectionToForm() {
        int row = typeTable.getSelectedRow();
        if (row < 0) {
            return;
        }
        idField.setText(String.valueOf(tableModel.getValueAt(row, 0)));
        nameField.setText(String.valueOf(tableModel.getValueAt(row, 1)));
        descriptionField.setText(String.valueOf(tableModel.getValueAt(row, 2)));
        statusBox.setSelectedItem(String.valueOf(tableModel.getValueAt(row, 3)));
    }

    private void clearForm() {
        typeTable.clearSelection();
        idField.setText("");
        nameField.setText("");
        descriptionField.setText("");
        statusBox.setSelectedItem(AssessmentType.STATUS_ACTIVE);
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private void showInformation(String message) {
        JOptionPane.showMessageDialog(this, message, "Assessment Types", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Assessment Types", JOptionPane.WARNING_MESSAGE);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Assessment Types", JOptionPane.ERROR_MESSAGE);
    }
}
