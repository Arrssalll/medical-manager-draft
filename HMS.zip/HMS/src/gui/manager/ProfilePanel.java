package gui.manager;

import model.MedicalManager;
import service.MedicalManagerService;
import util.ValidationUtil;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

/**
 * Lets the signed-in Medical Manager see and update their own details.
 *
 * The record comes from the manager accounts kept by the Administrative
 * Staff module, so this screen reads and saves through
 * MedicalManagerService instead of storing anything of its own.
 *
 * Only the display name can be changed here. The username, the account
 * status and the password decide how the account signs in, and those stay
 * with the administrator who created the account.
 */
public class ProfilePanel extends JPanel {

    private final MedicalManagerService managerService = new MedicalManagerService();
    private final String username;

    private final JTextField idField = new JTextField(14);
    private final JTextField nameField = new JTextField(22);
    private final JTextField usernameField = new JTextField(18);
    private final JTextField statusField = new JTextField(12);

    private MedicalManager currentManager;

    public ProfilePanel(String username) {
        this.username = username;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel heading = new JLabel("My Profile");
        heading.setFont(new Font("SansSerif", Font.BOLD, 16));
        add(heading, BorderLayout.NORTH);

        add(buildForm(), BorderLayout.CENTER);

        // These three describe the login account itself, so they are shown
        // for reference but cannot be edited from this screen.
        idField.setEditable(false);
        usernameField.setEditable(false);
        statusField.setEditable(false);

        loadProfile();
    }

    private JPanel buildForm() {
        JPanel form = new JPanel(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        form.add(new JLabel("Manager ID:"), gbc);
        gbc.gridx = 1;
        form.add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        form.add(new JLabel("Full Name:"), gbc);
        gbc.gridx = 1;
        form.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        form.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        form.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        form.add(new JLabel("Account Status:"), gbc);
        gbc.gridx = 1;
        form.add(statusField, gbc);

        JButton saveButton = new JButton("Save Changes");
        JButton reloadButton = new JButton("Reload");
        saveButton.addActionListener(e -> saveProfile());
        reloadButton.addActionListener(e -> loadProfile());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        buttons.add(saveButton);
        buttons.add(reloadButton);

        gbc.gridx = 1;
        gbc.gridy = 4;
        form.add(buttons, gbc);

        JLabel note = new JLabel("Username, status and password are managed by Administrative Staff.");
        note.setFont(new Font("SansSerif", Font.ITALIC, 12));
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        form.add(note, gbc);

        return form;
    }

    /**
     * Finds the signed-in manager among the stored manager records.
     */
    private MedicalManager findByUsername() {
        for (MedicalManager manager : managerService.getAll()) {
            if (manager.getUsername().equalsIgnoreCase(username)) {
                return manager;
            }
        }
        return null;
    }

    private void loadProfile() {
        currentManager = findByUsername();

        if (currentManager == null) {
            idField.setText("");
            nameField.setText("");
            usernameField.setText(username);
            statusField.setText("");
            nameField.setEnabled(false);
            JOptionPane.showMessageDialog(this,
                    "No manager profile was found for '" + username + "'.\n"
                            + "Ask Administrative Staff to check the manager record for this account.",
                    "Profile Not Found", JOptionPane.WARNING_MESSAGE);
            return;
        }

        nameField.setEnabled(true);
        idField.setText(currentManager.getUserId());
        nameField.setText(currentManager.getName());
        usernameField.setText(currentManager.getUsername());
        statusField.setText(currentManager.getStatus());
    }

    private void saveProfile() {
        if (currentManager == null) {
            JOptionPane.showMessageDialog(this, "There is no profile loaded to save.",
                    "My Profile", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String newName = nameField.getText().trim();
        if (!ValidationUtil.isNotEmpty(newName)) {
            JOptionPane.showMessageDialog(this, "Please enter your full name.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // The stored record is rebuilt with the new name so the username and
        // status already on file are written back exactly as they were.
        MedicalManager updated = new MedicalManager(currentManager.getUserId(), newName,
                currentManager.getUsername(), "----", currentManager.getStatus());

        if (managerService.update(currentManager.getUserId(), updated)) {
            currentManager = updated;
            JOptionPane.showMessageDialog(this, "Your profile has been updated.",
                    "My Profile", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "The profile could not be saved.",
                    "My Profile", JOptionPane.ERROR_MESSAGE);
        }
    }
}
