package gui.manager;

import model.HospitalMetrics;
import model.RevenueSummary;
import service.ReportService;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

/**
 * Shows the Medical Manager's two read-only reports.
 *
 * The figures are worked out by ReportService. This screen only lays the
 * results out as readable lines, so no counting or adding up happens in the
 * user interface.
 */
public class ReportsPanel extends JPanel {

    private final ReportService reportService = new ReportService();

    private final JTextArea metricsArea = new JTextArea();
    private final JTextArea revenueArea = new JTextArea();

    public ReportsPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel heading = new JLabel("Hospital Reports");
        heading.setFont(new Font("SansSerif", Font.BOLD, 16));
        add(heading, BorderLayout.NORTH);

        prepareArea(metricsArea);
        prepareArea(revenueArea);

        JTabbedPane reportTabs = new JTabbedPane();
        reportTabs.addTab("Hospital Metrics", new JScrollPane(metricsArea));
        reportTabs.addTab("Revenue Summary", new JScrollPane(revenueArea));
        add(reportTabs, BorderLayout.CENTER);

        JButton refreshButton = new JButton("Refresh Reports");
        refreshButton.addActionListener(e -> refreshReports());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.add(refreshButton);
        add(buttons, BorderLayout.SOUTH);

        refreshReports();
    }

    private void prepareArea(JTextArea area) {
        area.setEditable(false);
        area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        area.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    }

    /**
     * Rebuilds both reports from what is currently stored.
     */
    public final void refreshReports() {
        buildMetricsReport();
        buildRevenueReport();
    }

    private void buildMetricsReport() {
        StringBuilder text = new StringBuilder();
        try {
            HospitalMetrics metrics = reportService.getHospitalMetrics();

            text.append("HOSPITAL METRICS\n");
            text.append("================\n\n");

            text.append("Clinical structure\n");
            text.append("------------------\n");
            text.append(row("Departments", metrics.getTotalDepartments()));
            text.append(row("  Active", metrics.getActiveDepartments()));
            text.append(row("Assessment types", metrics.getTotalAssessmentTypes()));
            text.append(row("  Active", metrics.getActiveAssessmentTypes()));

            text.append("\nStaff and patients\n");
            text.append("------------------\n");
            text.append(row("Doctors", metrics.getTotalDoctors()));
            text.append(row("  Assigned to a manager", metrics.getAssignedDoctors()));
            text.append(row("  With a schedule", metrics.getDoctorsWithSchedules()));
            text.append(row("Patients registered", metrics.getTotalPatients()));

            text.append("\nConsultation slots\n");
            text.append("------------------\n");
            text.append(row("Total slots", metrics.getTotalScheduleSlots()));
            text.append(row("  Available", metrics.getAvailableSlots()));
            text.append(row("  Booked", metrics.getBookedSlots()));
            text.append(row("  Unavailable", metrics.getUnavailableSlots()));

            if (!metrics.getMissingSources().isEmpty()) {
                text.append("\nNot available yet\n");
                text.append("-----------------\n");
                for (String source : metrics.getMissingSources()) {
                    text.append("  ").append(source).append('\n');
                }
                text.append("\nThese modules are still being built by other members of the group,\n");
                text.append("so no figure is shown for them.\n");
            }
        } catch (RuntimeException e) {
            text.setLength(0);
            text.append("The hospital metrics could not be produced.\n\n").append(e.getMessage());
        }

        metricsArea.setText(text.toString());
        metricsArea.setCaretPosition(0);
    }

    private void buildRevenueReport() {
        StringBuilder text = new StringBuilder();
        try {
            RevenueSummary summary = reportService.getRevenueSummary();

            text.append("REVENUE SUMMARY\n");
            text.append("===============\n\n");

            if (!summary.hasBills()) {
                text.append("There are no billing records yet.\n\n");
                text.append("Bills are created by the Administrative Staff module. Once bills\n");
                text.append("exist, the totals will appear here automatically.\n");
            } else {
                text.append("Bills\n");
                text.append("-----\n");
                text.append(row("Total bills", summary.getTotalBills()));
                text.append(row("  Paid", summary.getPaidBills()));
                text.append(row("  Pending", summary.getPendingBills()));
                text.append(row("  Unpaid", summary.getUnpaidBills()));

                text.append("\nAmounts\n");
                text.append("-------\n");
                text.append(money("Total billed", summary.getTotalBilled()));
                text.append(money("Collected (paid)", summary.getTotalCollected()));
                text.append(money("Outstanding", summary.getOutstanding()));

                text.append("\nRevenue is counted as collected once a bill is marked PAID.\n");
                text.append("Billing records belong to Administrative Staff and are only read here.\n");
            }
        } catch (RuntimeException e) {
            text.setLength(0);
            text.append("The revenue summary could not be produced.\n\n").append(e.getMessage());
        }

        revenueArea.setText(text.toString());
        revenueArea.setCaretPosition(0);
    }

    private String row(String label, int value) {
        return String.format("  %-26s %d%n", label + ":", value);
    }

    private String money(String label, double value) {
        return String.format("  %-26s RM %,.2f%n", label + ":", value);
    }
}
