package gui.manager;

import model.Department;
import service.DepartmentService;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;

/**
 * Screen for managing the hospital's clinical departments.
 *
 * The screen collects what the user types and hands it to DepartmentService.
 * Checking for empty values, repeated names and unknown identifiers is left
 * to the service and the Department class, so the rules stay in one place and
 * cannot drift apart from the rest of the module.
 */
public class DepartmentPanel extends JPanel {

    private final DepartmentService departmentService = new DepartmentService();

    private final DefaultTableModel tableModel =
            new DefaultTableModel(new String[]{"Department ID", "Name", "Specialty", "Status"}, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    // Records are changed through the form, not by typing in
                    // the table, so that every change passes the service.
                    return false;
                }
            };

    private final JTable departmentTable = new JTable(tableModel);
    private final JTextField idField = new JTextField(10);
    private final JTextField nameField = new JTextField(18);
    private final JTextField specialtyField = new JTextField(22);
    private final JComboBox<String> statusBox =
            new JComboBox<>(new String[]{Department.STATUS_ACTIVE, Department.STATUS_INACTIVE});

    public DepartmentPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel heading = new JLabel("Manage Departments");
        heading.setFont(heading.getFont().deriveFont(Font.BOLD, 18f));
        add(heading, BorderLayout.NORTH);

        departmentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        departmentTable.getSelectionModel().addListSelectionListener(e -> copySelectionToForm());
        add(new JScrollPane(departmentTable), BorderLayout.CENTER);

        add(buildForm(), BorderLayout.SOUTH);

        // The identifier is produced by the module, so it is shown but never
        // typed in by hand.
        idField.setEditable(false);

        reloadTable();
    }

    private JPanel buildForm() {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Department details"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        form.add(new JLabel("Department ID:"), gbc);
        gbc.gridx = 1;
        form.add(idField, gbc);

        gbc.gridx = 2;
        form.add(new JLabel("Status:"), gbc);
        gbc.gridx = 3;
        form.add(statusBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        form.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1;
        form.add(nameField, gbc);

        gbc.gridx = 2;
        form.add(new JLabel("Specialty:"), gbc);
        gbc.gridx = 3;
        form.add(specialtyField, gbc);

        JPanel buttons = new JPanel();
        JButton addButton = new JButton("Add");
        JButton updateButton = new JButton("Update");
        JButton findButton = new JButton("Find by ID");
        JButton refreshButton = new JButton("Refresh");
        JButton clearButton = new JButton("Clear");

        addButton.addActionListener(e -> addDepartment());
        updateButton.addActionListener(e -> updateDepartment());
        findButton.addActionListener(e -> findDepartment());
        refreshButton.addActionListener(e -> reloadTable());
        clearButton.addActionListener(e -> clearForm());

        buttons.add(addButton);
        buttons.add(updateButton);
        buttons.add(findButton);
        buttons.add(refreshButton);
        buttons.add(clearButton);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 4;
        form.add(buttons, gbc);

        return form;
    }

    /**
     * Reads every stored department and rebuilds the table.
     */
    public final void reloadTable() {
        tableModel.setRowCount(0);
        try {
            List<Department> departments = departmentService.getAllDepartments();
            for (Department department : departments) {
                tableModel.addRow(new Object[]{
                        department.getDepartmentID(),
                        department.getDepartmentName(),
                        department.getSpecialty(),
                        department.getStatus()
                });
            }
        } catch (RuntimeException e) {
            showError("The department records could not be loaded.\n" + e.getMessage());
        }
    }

    private void addDepartment() {
        if (isBlank(nameField.getText()) || isBlank(specialtyField.getText())) {
            showWarning("Please fill in all required fields.");
            return;
        }

        try {
            Department created = departmentService.addDepartment(
                    nameField.getText(), specialtyField.getText());
            reloadTable();
            clearForm();
            showInformation("Department " + created.getDepartmentID() + " has been added.");
        } catch (IllegalArgumentException | IllegalStateException e) {
            showWarning(e.getMessage());
        } catch (RuntimeException e) {
            showError("The department could not be saved.\n" + e.getMessage());
        }
    }

    private void updateDepartment() {
        if (isBlank(idField.getText())) {
            showWarning("Please select the department you want to update.");
            return;
        }
        if (isBlank(nameField.getText()) || isBlank(specialtyField.getText())) {
            showWarning("Please fill in all required fields.");
            return;
        }

        try {
            departmentService.updateDepartment(
                    idField.getText(),
                    nameField.getText(),
                    specialtyField.getText(),
                    String.valueOf(statusBox.getSelectedItem()));
            reloadTable();
            showInformation("Department " + idField.getText().trim() + " has been updated.");
        } catch (IllegalArgumentException | IllegalStateException e) {
            showWarning(e.getMessage());
        } catch (RuntimeException e) {
            showError("The changes could not be saved.\n" + e.getMessage());
        }
    }

    private void findDepartment() {
        String wanted = JOptionPane.showInputDialog(this, "Enter the department ID to find:");
        if (wanted == null || isBlank(wanted)) {
            return;
        }

        try {
            Department found = departmentService.findDepartmentById(wanted);
            if (found == null) {
                showWarning("Record not found.");
                return;
            }
            selectRowWithId(found.getDepartmentID());
        } catch (IllegalArgumentException e) {
            showWarning(e.getMessage());
        } catch (RuntimeException e) {
            showError("The search could not be completed.\n" + e.getMessage());
        }
    }

    private void selectRowWithId(String departmentId) {
        for (int row = 0; row < tableModel.getRowCount(); row++) {
            if (departmentId.equalsIgnoreCase(String.valueOf(tableModel.getValueAt(row, 0)))) {
                departmentTable.setRowSelectionInterval(row, row);
                departmentTable.scrollRectToVisible(departmentTable.getCellRect(row, 0, true));
                return;
            }
        }
    }

    private void copySelectionToForm() {
        int row = departmentTable.getSelectedRow();
        if (row < 0) {
            return;
        }
        idField.setText(String.valueOf(tableModel.getValueAt(row, 0)));
        nameField.setText(String.valueOf(tableModel.getValueAt(row, 1)));
        specialtyField.setText(String.valueOf(tableModel.getValueAt(row, 2)));
        statusBox.setSelectedItem(String.valueOf(tableModel.getValueAt(row, 3)));
    }

    private void clearForm() {
        departmentTable.clearSelection();
        idField.setText("");
        nameField.setText("");
        specialtyField.setText("");
        statusBox.setSelectedItem(Department.STATUS_ACTIVE);
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private void showInformation(String message) {
        JOptionPane.showMessageDialog(this, message, "Departments", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Departments", JOptionPane.WARNING_MESSAGE);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Departments", JOptionPane.ERROR_MESSAGE);
    }
}
