package gui.manager;

import model.DoctorSchedule;
import service.DoctorScheduleService;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;

/**
 * Screen for building and adjusting doctors' working schedules.
 *
 * Checks on the date, the times and clashes with an existing slot are done by
 * DoctorScheduleService, so this screen passes the typed values straight
 * through and reports back whatever the service says.
 *
 * One extra rule is applied here rather than in the service: a slot that is
 * already BOOKED is not edited from this screen. A booked slot is tied to a
 * patient's appointment, and the part of the system that creates appointments
 * has not been built yet, so changing the slot could leave that appointment
 * pointing at a time that no longer exists. The service itself stays general
 * so that the Patient screens can still set a slot to BOOKED when booking is
 * added.
 */
public class DoctorSchedulePanel extends JPanel {

    private final DoctorScheduleService scheduleService = new DoctorScheduleService();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"Schedule ID", "Doctor ID", "Date", "Start", "End", "Status"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable scheduleTable = new JTable(tableModel);
    private final JTextField idField = new JTextField(9);
    private final JTextField doctorField = new JTextField(9);
    private final JTextField dateField = new JTextField(10);
    private final JTextField startField = new JTextField(6);
    private final JTextField endField = new JTextField(6);
    private final JComboBox<String> statusBox = new JComboBox<>(new String[]{
            DoctorSchedule.STATUS_AVAILABLE,
            DoctorSchedule.STATUS_BOOKED,
            DoctorSchedule.STATUS_UNAVAILABLE});

    public DoctorSchedulePanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel heading = new JLabel("Doctor Schedules");
        heading.setFont(heading.getFont().deriveFont(Font.BOLD, 18f));
        add(heading, BorderLayout.NORTH);

        scheduleTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scheduleTable.getSelectionModel().addListSelectionListener(e -> copySelectionToForm());
        add(new JScrollPane(scheduleTable), BorderLayout.CENTER);

        add(buildForm(), BorderLayout.SOUTH);

        idField.setEditable(false);
        reloadTable();
    }

    private JPanel buildForm() {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Schedule details"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        form.add(new JLabel("Schedule ID:"), gbc);
        gbc.gridx = 1;
        form.add(idField, gbc);

        gbc.gridx = 2;
        form.add(new JLabel("Doctor ID:"), gbc);
        gbc.gridx = 3;
        form.add(doctorField, gbc);

        gbc.gridx = 4;
        form.add(new JLabel("Date (yyyy-MM-dd):"), gbc);
        gbc.gridx = 5;
        form.add(dateField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        form.add(new JLabel("Start (HH:mm):"), gbc);
        gbc.gridx = 1;
        form.add(startField, gbc);

        gbc.gridx = 2;
        form.add(new JLabel("End (HH:mm):"), gbc);
        gbc.gridx = 3;
        form.add(endField, gbc);

        gbc.gridx = 4;
        form.add(new JLabel("Status:"), gbc);
        gbc.gridx = 5;
        form.add(statusBox, gbc);

        JPanel buttons = new JPanel();
        JButton addButton = new JButton("Add");
        JButton updateButton = new JButton("Update");
        JButton doctorFilterButton = new JButton("Filter by Doctor");
        JButton availableButton = new JButton("Show Available");
        JButton allButton = new JButton("Show All");
        JButton clearButton = new JButton("Clear");

        addButton.addActionListener(e -> addSchedule());
        updateButton.addActionListener(e -> updateSchedule());
        doctorFilterButton.addActionListener(e -> filterByDoctor());
        availableButton.addActionListener(e -> showAvailableOnly());
        allButton.addActionListener(e -> reloadTable());
        clearButton.addActionListener(e -> clearForm());

        buttons.add(addButton);
        buttons.add(updateButton);
        buttons.add(doctorFilterButton);
        buttons.add(availableButton);
        buttons.add(allButton);
        buttons.add(clearButton);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 6;
        form.add(buttons, gbc);

        return form;
    }

    public final void reloadTable() {
        try {
            populate(scheduleService.getAllSchedules());
        } catch (RuntimeException e) {
            showError("The schedules could not be loaded.\n" + e.getMessage());
        }
    }

    private void populate(List<DoctorSchedule> schedules) {
        tableModel.setRowCount(0);
        for (DoctorSchedule schedule : schedules) {
            tableModel.addRow(new Object[]{
                    schedule.getScheduleID(),
                    schedule.getDoctorID(),
                    schedule.getDate(),
                    schedule.getStartTime(),
                    schedule.getEndTime(),
                    schedule.getStatus()
            });
        }
    }

    private void addSchedule() {
        if (isBlank(doctorField.getText()) || isBlank(dateField.getText())
                || isBlank(startField.getText()) || isBlank(endField.getText())) {
            showWarning("Please fill in all required fields.");
            return;
        }

        try {
            DoctorSchedule created = scheduleService.addSchedule(
                    doctorField.getText(),
                    dateField.getText(),
                    startField.getText(),
                    endField.getText());
            reloadTable();
            clearForm();
            showInformation("Schedule " + created.getScheduleID() + " has been added.");
        } catch (IllegalArgumentException | IllegalStateException e) {
            showWarning(e.getMessage());
        } catch (RuntimeException e) {
            showError("The schedule could not be saved.\n" + e.getMessage());
        }
    }

    private void updateSchedule() {
        if (isBlank(idField.getText())) {
            showWarning("Please select the schedule you want to update.");
            return;
        }
        if (isBlank(dateField.getText()) || isBlank(startField.getText()) || isBlank(endField.getText())) {
            showWarning("Please fill in all required fields.");
            return;
        }

        String scheduleId = idField.getText().trim();

        try {
            // The stored status is checked, not the one shown in the form, so
            // that a booked slot cannot be edited by simply changing the
            // status box first.
            DoctorSchedule stored = findStoredSchedule(scheduleId);
            if (stored == null) {
                showWarning("Record not found.");
                return;
            }

            if (DoctorSchedule.STATUS_BOOKED.equals(stored.getStatus())) {
                showWarning("Schedule " + scheduleId + " is already booked by a patient and cannot be "
                        + "changed here.\nThe booking would no longer match the doctor's time.");
                return;
            }

            scheduleService.updateSchedule(
                    scheduleId,
                    dateField.getText(),
                    startField.getText(),
                    endField.getText(),
                    String.valueOf(statusBox.getSelectedItem()));
            reloadTable();
            showInformation("Schedule " + scheduleId + " has been updated.");
        } catch (IllegalArgumentException | IllegalStateException e) {
            showWarning(e.getMessage());
        } catch (RuntimeException e) {
            showError("The changes could not be saved.\n" + e.getMessage());
        }
    }

    private DoctorSchedule findStoredSchedule(String scheduleId) {
        for (DoctorSchedule schedule : scheduleService.getAllSchedules()) {
            if (schedule.getScheduleID().equalsIgnoreCase(scheduleId)) {
                return schedule;
            }
        }
        return null;
    }

    private void filterByDoctor() {
        String doctorId = JOptionPane.showInputDialog(this, "Enter the doctor ID to filter by:");
        if (doctorId == null || isBlank(doctorId)) {
            return;
        }

        try {
            List<DoctorSchedule> found = scheduleService.getSchedulesByDoctor(doctorId);
            populate(found);
            if (found.isEmpty()) {
                showInformation("No schedules were found for doctor " + doctorId.trim() + ".");
            }
        } catch (IllegalArgumentException e) {
            showWarning(e.getMessage());
        } catch (RuntimeException e) {
            showError("The schedules could not be filtered.\n" + e.getMessage());
        }
    }

    private void showAvailableOnly() {
        try {
            List<DoctorSchedule> available = scheduleService.getAvailableSchedules();
            populate(available);
            if (available.isEmpty()) {
                showInformation("There are no available slots at the moment.");
            }
        } catch (RuntimeException e) {
            showError("The available slots could not be listed.\n" + e.getMessage());
        }
    }

    private void copySelectionToForm() {
        int row = scheduleTable.getSelectedRow();
        if (row < 0) {
            return;
        }
        idField.setText(String.valueOf(tableModel.getValueAt(row, 0)));
        doctorField.setText(String.valueOf(tableModel.getValueAt(row, 1)));
        dateField.setText(String.valueOf(tableModel.getValueAt(row, 2)));
        startField.setText(String.valueOf(tableModel.getValueAt(row, 3)));
        endField.setText(String.valueOf(tableModel.getValueAt(row, 4)));
        statusBox.setSelectedItem(String.valueOf(tableModel.getValueAt(row, 5)));
    }

    private void clearForm() {
        scheduleTable.clearSelection();
        idField.setText("");
        doctorField.setText("");
        dateField.setText("");
        startField.setText("");
        endField.setText("");
        statusBox.setSelectedItem(DoctorSchedule.STATUS_AVAILABLE);
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private void showInformation(String message) {
        JOptionPane.showMessageDialog(this, message, "Doctor Schedules", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Doctor Schedules", JOptionPane.WARNING_MESSAGE);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Doctor Schedules", JOptionPane.ERROR_MESSAGE);
    }
}
