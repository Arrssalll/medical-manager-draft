/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui.admin;
import gui.LoginFrame;

import javax.swing.*;
import java.awt.*;


/**
 *
 * @author dhanj
 */
public class AdminDashboard extends JFrame {


    public AdminDashboard(String username) {
        setTitle("APU Medical Centre HMS - Administrative Staff Dashboard");
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        JLabel welcome = new JLabel("Welcome, " + username + " (Administrative Staff)");
        welcome.setFont(new Font("SansSerif", Font.BOLD, 14));
        JButton logoutButton = new JButton("Logout");
        topBar.add(welcome, BorderLayout.WEST);
        topBar.add(logoutButton, BorderLayout.EAST);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Manage Users", new UserManagementPanel());
        tabs.addTab("Doctor <-> Manager Assignment", new DoctorAssignmentPanel());
        tabs.addTab("Hospital Assets", new AssetManagementPanel());
        tabs.addTab("Consultation Rates", new ConsultationRatePanel());
        tabs.addTab("Insurance Networks", new InsuranceNetworkPanel());
        tabs.addTab("Bill Overview", new BillOverviewPanel());

        setLayout(new BorderLayout());
        add(topBar, BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);

        logoutButton.addActionListener(e -> {
            int choice = JOptionPane.showConfirmDialog(this, "Log out and return to login screen?",
                    "Confirm Logout", JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION) {
                dispose();
                new LoginFrame().setVisible(true);
            }
        });
    }
}
    

