/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui.admin;
import model.InsuranceNetwork;
import service.InsuranceNetworkService;
import util.ValidationUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 *
 * @author dhanj
 */
public class InsuranceNetworkPanel extends JPanel {
 private final InsuranceNetworkService insuranceService = new InsuranceNetworkService();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"Insurance ID", "Provider", "Coverage (%)", "Status"}, 0) {
        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
        }
    };
    private final JTable table = new JTable(tableModel);

    public InsuranceNetworkPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton addButton = new JButton("Add Provider");
        JButton editButton = new JButton("Edit Selected");
        JButton deleteButton = new JButton("Delete Selected");
        JButton refreshButton = new JButton("Refresh");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(e -> openForm(null));
        editButton.addActionListener(e -> {
            InsuranceNetwork selected = getSelected();
            if (selected == null) {
                showError("Please select a provider from the table first.");
                return;
            }
            openForm(selected);
        });
        deleteButton.addActionListener(e -> deleteSelected());
        refreshButton.addActionListener(e -> refreshTable());

        refreshTable();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (InsuranceNetwork i : insuranceService.getAll()) {
            tableModel.addRow(new Object[]{i.getInsuranceId(), i.getProviderName(),
                    i.getCoveragePercentage(), i.getStatus()});
        }
    }

    private InsuranceNetwork getSelected() {
        int row = table.getSelectedRow();
        if (row == -1) return null;
        String id = (String) tableModel.getValueAt(row, 0);
        return insuranceService.getById(id);
    }

    private void openForm(InsuranceNetwork existing) {
        JTextField nameField = new JTextField();
        JTextField coverageField = new JTextField();
        JComboBox<String> statusBox = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE"});

        if (existing != null) {
            nameField.setText(existing.getProviderName());
            coverageField.setText(String.valueOf(existing.getCoveragePercentage()));
            statusBox.setSelectedItem(existing.getStatus());
        }

        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        panel.add(new JLabel("Provider Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Coverage (%):"));
        panel.add(coverageField);
        panel.add(new JLabel("Status:"));
        panel.add(statusBox);

        String dialogTitle = existing == null ? "Add Insurance Provider" : "Edit Insurance Provider";
        int result = JOptionPane.showConfirmDialog(this, panel, dialogTitle,
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        String name = nameField.getText().trim();
        String coverageText = coverageField.getText().trim();
        String status = (String) statusBox.getSelectedItem();

        if (!ValidationUtil.isNotEmpty(name)) {
            showError("Provider name cannot be empty.");
            return;
        }
        if (!ValidationUtil.isValidPercentage(coverageText)) {
            showError("Coverage must be a number between 0 and 100.");
            return;
        }

        double coverage = Double.parseDouble(coverageText);
        if (existing == null) {
            insuranceService.createInsurance(name, coverage, status);
        } else {
            existing.setProviderName(name);
            existing.setCoveragePercentage(coverage);
            existing.setStatus(status);
            insuranceService.update(existing.getInsuranceId(), existing);
        }
        refreshTable();
    }

    private void deleteSelected() {
        InsuranceNetwork selected = getSelected();
        if (selected == null) {
            showError("Please select a provider from the table first.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete provider " + selected.getInsuranceId() + "?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            insuranceService.delete(selected.getInsuranceId());
            refreshTable();
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Validation Error", JOptionPane.WARNING_MESSAGE);
    }   
    
}
