/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui.admin;
import model.ConsultationRate;
import service.ConsultationRateService;
import util.ValidationUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 *
 * @author dhanj
 */
public class ConsultationRatePanel extends JPanel {
    
    private final ConsultationRateService rateService = new ConsultationRateService();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"Rate ID", "Department/Type", "Amount (RM)", "Status"}, 0) {
        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
        }
    };
    private final JTable table = new JTable(tableModel);

    public ConsultationRatePanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton addButton = new JButton("Add Rate");
        JButton editButton = new JButton("Edit Selected");
        JButton deleteButton = new JButton("Delete Selected");
        JButton refreshButton = new JButton("Refresh");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(e -> openForm(null));
        editButton.addActionListener(e -> {
            ConsultationRate selected = getSelectedRate();
            if (selected == null) {
                showError("Please select a rate from the table first.");
                return;
            }
            openForm(selected);
        });
        deleteButton.addActionListener(e -> deleteSelected());
        refreshButton.addActionListener(e -> refreshTable());

        refreshTable();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (ConsultationRate r : rateService.getAll()) {
            tableModel.addRow(new Object[]{r.getRateId(), r.getDepartmentOrType(),
                    String.format("%.2f", r.getAmount()), r.getStatus()});
        }
    }

    private ConsultationRate getSelectedRate() {
        int row = table.getSelectedRow();
        if (row == -1) return null;
        String id = (String) tableModel.getValueAt(row, 0);
        return rateService.getById(id);
    }

    private void openForm(ConsultationRate existing) {
        JTextField typeField = new JTextField();
        JTextField amountField = new JTextField();
        JComboBox<String> statusBox = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE"});

        if (existing != null) {
            typeField.setText(existing.getDepartmentOrType());
            amountField.setText(String.valueOf(existing.getAmount()));
            statusBox.setSelectedItem(existing.getStatus());
        }

        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        panel.add(new JLabel("Department / Consultation Type:"));
        panel.add(typeField);
        panel.add(new JLabel("Amount (RM):"));
        panel.add(amountField);
        panel.add(new JLabel("Status:"));
        panel.add(statusBox);

        String dialogTitle = existing == null ? "Add Consultation Rate" : "Edit Consultation Rate";
        int result = JOptionPane.showConfirmDialog(this, panel, dialogTitle,
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        String type = typeField.getText().trim();
        String amountText = amountField.getText().trim();
        String status = (String) statusBox.getSelectedItem();

        if (!ValidationUtil.isNotEmpty(type)) {
            showError("Department/type cannot be empty.");
            return;
        }
        if (!ValidationUtil.isValidAmount(amountText)) {
            showError("Amount must be a valid non-negative number.");
            return;
        }

        double amount = Double.parseDouble(amountText);
        if (existing == null) {
            rateService.createRate(type, amount, status);
        } else {
            existing.setDepartmentOrType(type);
            existing.setAmount(amount);
            existing.setStatus(status);
            rateService.update(existing.getRateId(), existing);
        }
        refreshTable();
    }

    private void deleteSelected() {
        ConsultationRate selected = getSelectedRate();
        if (selected == null) {
            showError("Please select a rate from the table first.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete rate " + selected.getRateId() + "?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            rateService.delete(selected.getRateId());
            refreshTable();
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Validation Error", JOptionPane.WARNING_MESSAGE);
    }

}
