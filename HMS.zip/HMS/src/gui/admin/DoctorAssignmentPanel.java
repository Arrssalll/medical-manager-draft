/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui.admin;
import model.Doctor;
import model.MedicalManager;
import service.DoctorService;
import service.MedicalManagerService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 *
 * @author dhanj
 */
public class DoctorAssignmentPanel extends JPanel {
    private final DoctorService doctorService = new DoctorService();
    private final MedicalManagerService managerService = new MedicalManagerService();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"Doctor ID", "Name", "Department", "Specialty", "Current Manager"}, 0) {
        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
        }
    };
    private final JTable table = new JTable(tableModel);

    public DoctorAssignmentPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton assignButton = new JButton("Assign Selected Doctor to Manager");
        JButton refreshButton = new JButton("Refresh");
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(assignButton);
        buttonPanel.add(refreshButton);
        add(buttonPanel, BorderLayout.SOUTH);

        assignButton.addActionListener(e -> assignSelectedDoctor());
        refreshButton.addActionListener(e -> refreshTable());

        refreshTable();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Doctor d : doctorService.getAll()) {
            tableModel.addRow(new Object[]{
                    d.getUserId(), d.getName(), d.getDepartment(), d.getSpecialty(), d.getManagerId()
            });
        }
    }

    private void assignSelectedDoctor() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a doctor from the table first.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String doctorId = (String) tableModel.getValueAt(row, 0);

        List<MedicalManager> managers = managerService.getAll();
        if (managers.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No medical managers exist yet. Create one under 'Manage Users' first.",
                    "No Managers Available", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String[] options = managers.stream()
                .map(m -> m.getUserId() + " - " + m.getName())
                .toArray(String[]::new);

        String choice = (String) JOptionPane.showInputDialog(this, "Select a Medical Manager:",
                "Assign Doctor", JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
        if (choice == null) return;

        String managerId = choice.split(" - ")[0];
        boolean success = doctorService.assignManager(doctorId, managerId);
        if (success) {
            JOptionPane.showMessageDialog(this, "Doctor " + doctorId + " assigned to " + managerId + ".");
            refreshTable();
        } else {
            JOptionPane.showMessageDialog(this, "Assignment failed.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
}
