/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui.admin;
import model.Bill;
import service.BillService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 *
 * @author dhanj
 */
public class BillOverviewPanel extends JPanel {
  private final BillService billService = new BillService();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"Bill ID", "Patient ID", "Amount (RM)", "Status"}, 0) {
        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
        }
    };
    private final JTable table = new JTable(tableModel);

    public BillOverviewPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton markPendingButton = new JButton("Mark PENDING");
        JButton markPaidButton = new JButton("Mark PAID");
        JButton refreshButton = new JButton("Refresh");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(markPendingButton);
        buttonPanel.add(markPaidButton);
        buttonPanel.add(refreshButton);
        add(buttonPanel, BorderLayout.SOUTH);

        markPendingButton.addActionListener(e -> updateStatus("PENDING"));
        markPaidButton.addActionListener(e -> updateStatus("PAID"));
        refreshButton.addActionListener(e -> refreshTable());

        refreshTable();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Bill b : billService.getAll()) {
            tableModel.addRow(new Object[]{b.getBillId(), b.getPatientId(),
                    String.format("%.2f", b.getAmount()), b.getStatus()});
        }
    }

    private void updateStatus(String status) {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a bill from the table first.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String billId = (String) tableModel.getValueAt(row, 0);
        billService.updateStatus(billId, status);
        refreshTable();
    }  
    
}
