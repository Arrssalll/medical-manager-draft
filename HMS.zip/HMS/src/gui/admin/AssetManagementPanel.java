/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui.admin;
import model.HospitalAsset;
import service.AssetService;
import util.ValidationUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 *
 * @author dhanj
 */
public class AssetManagementPanel extends JPanel {
 
    private final AssetService assetService = new AssetService();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"Asset ID", "Type", "Name", "Location", "Status"}, 0) {
        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
        }
    };
    private final JTable table = new JTable(tableModel);

    public AssetManagementPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton addButton = new JButton("Add Asset");
        JButton editButton = new JButton("Edit Selected");
        JButton toggleButton = new JButton("Toggle Available/Unavailable");
        JButton deleteButton = new JButton("Delete Selected");
        JButton refreshButton = new JButton("Refresh");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(toggleButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(e -> openForm(null));
        editButton.addActionListener(e -> {
            HospitalAsset selected = getSelectedAsset();
            if (selected == null) {
                showError("Please select an asset from the table first.");
                return;
            }
            openForm(selected);
        });
        toggleButton.addActionListener(e -> toggleStatus());
        deleteButton.addActionListener(e -> deleteSelected());
        refreshButton.addActionListener(e -> refreshTable());

        refreshTable();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (HospitalAsset a : assetService.getAll()) {
            tableModel.addRow(new Object[]{a.getAssetId(), a.getType(), a.getName(), a.getLocation(), a.getStatus()});
        }
    }

    private HospitalAsset getSelectedAsset() {
        int row = table.getSelectedRow();
        if (row == -1) return null;
        String id = (String) tableModel.getValueAt(row, 0);
        return assetService.getById(id);
    }

    private void openForm(HospitalAsset existing) {
        JComboBox<String> typeBox = new JComboBox<>(HospitalAsset.VALID_TYPES);
        JTextField nameField = new JTextField();
        JTextField locationField = new JTextField();
        JComboBox<String> statusBox = new JComboBox<>(new String[]{"AVAILABLE", "UNAVAILABLE"});

        if (existing != null) {
            typeBox.setSelectedItem(existing.getType());
            nameField.setText(existing.getName());
            locationField.setText(existing.getLocation());
            statusBox.setSelectedItem(existing.getStatus());
        }

        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        panel.add(new JLabel("Type:"));
        panel.add(typeBox);
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Location:"));
        panel.add(locationField);
        panel.add(new JLabel("Status:"));
        panel.add(statusBox);

        String dialogTitle = existing == null ? "Add Hospital Asset" : "Edit Hospital Asset";
        int result = JOptionPane.showConfirmDialog(this, panel, dialogTitle,
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        String name = nameField.getText().trim();
        String location = locationField.getText().trim();
        String type = (String) typeBox.getSelectedItem();
        String status = (String) statusBox.getSelectedItem();

        if (!ValidationUtil.isNotEmpty(name) || !ValidationUtil.isNotEmpty(location)) {
            showError("Name and location cannot be empty.");
            return;
        }

        if (existing == null) {
            assetService.createAsset(type, name, location, status);
        } else {
            existing.setType(type);
            existing.setName(name);
            existing.setLocation(location);
            existing.setStatus(status);
            assetService.update(existing.getAssetId(), existing);
        }
        refreshTable();
    }

    private void toggleStatus() {
        HospitalAsset selected = getSelectedAsset();
        if (selected == null) {
            showError("Please select an asset from the table first.");
            return;
        }
        selected.setStatus(selected.getStatus().equals("AVAILABLE") ? "UNAVAILABLE" : "AVAILABLE");
        assetService.update(selected.getAssetId(), selected);
        refreshTable();
    }

    private void deleteSelected() {
        HospitalAsset selected = getSelectedAsset();
        if (selected == null) {
            showError("Please select an asset from the table first.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete asset " + selected.getAssetId() + "?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            assetService.delete(selected.getAssetId());
            refreshTable();
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Validation Error", JOptionPane.WARNING_MESSAGE);
    }   
    
}
