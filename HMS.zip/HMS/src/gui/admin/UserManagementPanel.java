/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui.admin;
import model.User;
import service.DoctorService;
import service.MedicalManagerService;
import service.UserManagementService;
import util.ValidationUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 *
 * @author dhanj
 */
public class UserManagementPanel extends JPanel {
   

    private final UserManagementService userService = new UserManagementService();
    private final DoctorService doctorService = new DoctorService();
    private final MedicalManagerService managerService = new MedicalManagerService();

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"ID", "Username", "Role", "Status"}, 0) {
        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
        }
    };
    private final JTable table = new JTable(tableModel);

    public UserManagementPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton createButton = new JButton("Create New User Account");
        JButton toggleStatusButton = new JButton("Toggle Active/Inactive");
        JButton resetPasswordButton = new JButton("Reset Password");
        JButton deleteButton = new JButton("Delete Selected");
        JButton refreshButton = new JButton("Refresh");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(createButton);
        buttonPanel.add(toggleStatusButton);
        buttonPanel.add(resetPasswordButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        add(buttonPanel, BorderLayout.SOUTH);

        createButton.addActionListener(e -> openCreateDialog());
        toggleStatusButton.addActionListener(e -> toggleStatus());
        resetPasswordButton.addActionListener(e -> resetPassword());
        deleteButton.addActionListener(e -> deleteSelected());
        refreshButton.addActionListener(e -> refreshTable());

        refreshTable();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (User u : userService.getAll()) {
            tableModel.addRow(new Object[]{u.getUserId(), u.getUsername(), u.getRole(), u.getStatus()});
        }
    }

    private String getSelectedId() {
        int row = table.getSelectedRow();
        if (row == -1) return null;
        return (String) tableModel.getValueAt(row, 0);
    }

    private void openCreateDialog() {
        JTextField nameField = new JTextField();
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JCheckBox showPasswordCheckbox = new JCheckBox("Show Password");
        JTextField departmentField = new JTextField();
        JTextField specialtyField = new JTextField();
        String[] roles = {"ADMIN", "MEDICAL_MANAGER", "DOCTOR", "PATIENT"};
        JComboBox<String> roleBox = new JComboBox<>(roles);
        String[] statuses = {"ACTIVE", "INACTIVE"};
        JComboBox<String> statusBox = new JComboBox<>(statuses);

        showPasswordCheckbox.addActionListener(e -> {
            if (showPasswordCheckbox.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('*');
            }
        });

        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        panel.add(new JLabel("Full Name (Doctor/Manager only):"));
        panel.add(nameField);
        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password (min 4 chars):"));
        panel.add(passwordField);
        panel.add(new JLabel(""));
        panel.add(showPasswordCheckbox);
        panel.add(new JLabel("Role:"));
        panel.add(roleBox);
        panel.add(new JLabel("Department (Doctor only):"));
        panel.add(departmentField);
        panel.add(new JLabel("Specialty (Doctor only):"));
        panel.add(specialtyField);
        panel.add(new JLabel("Status:"));
        panel.add(statusBox);

        int result = JOptionPane.showConfirmDialog(this, panel, "Create New User Account",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        String role = (String) roleBox.getSelectedItem();
        String status = (String) statusBox.getSelectedItem();

        if (!ValidationUtil.isValidUsername(username)) {
            showError("Username must be 4-20 characters (letters, numbers, underscore only).");
            return;
        }
        if (!ValidationUtil.isValidPassword(password)) {
            showError("Password must be at least 4 characters.");
            return;
        }
        if (userService.isUsernameTaken(username)) {
            showError("This username is already taken.");
            return;
        }

        boolean success;
        switch (role) {
            case "DOCTOR":
                if (!ValidationUtil.isNotEmpty(nameField.getText()) ||
                        !ValidationUtil.isNotEmpty(departmentField.getText()) ||
                        !ValidationUtil.isNotEmpty(specialtyField.getText())) {
                    showError("Name, department and specialty are required for a doctor account.");
                    return;
                }
                success = doctorService.createDoctor(nameField.getText().trim(), username, password,
                        departmentField.getText().trim(), specialtyField.getText().trim(), status) != null;
                break;
            case "MEDICAL_MANAGER":
                if (!ValidationUtil.isNotEmpty(nameField.getText())) {
                    showError("Name is required for a medical manager account.");
                    return;
                }
                success = managerService.createManager(nameField.getText().trim(), username, password, status) != null;
                break;
            default:
                success = userService.createLoginAccount(username, password, role, status) != null;
        }

        if (success) {
            JOptionPane.showMessageDialog(this, "Account created successfully.");
            refreshTable();
        } else {
            showError("Could not create account. Please check the details and try again.");
        }
    }

    private void toggleStatus() {
        String id = getSelectedId();
        if (id == null) {
            showError("Please select a user from the table first.");
            return;
        }
        User u = userService.getById(id);
        if (u == null) return;
        String newStatus = u.isActive() ? "INACTIVE" : "ACTIVE";
        userService.updateStatus(id, newStatus);
        refreshTable();
    }

    private void resetPassword() {
        String id = getSelectedId();
        if (id == null) {
            showError("Please select a user from the table first.");
            return;
        }

        JPasswordField newPasswordField = new JPasswordField();
        JCheckBox showPasswordCheckbox = new JCheckBox("Show Password");
        showPasswordCheckbox.addActionListener(e -> {
            if (showPasswordCheckbox.isSelected()) {
                newPasswordField.setEchoChar((char) 0);
            } else {
                newPasswordField.setEchoChar('*');
            }
        });

        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
        panel.add(new JLabel("Enter new password (min 4 characters):"));
        panel.add(newPasswordField);
        panel.add(showPasswordCheckbox);

        int result = JOptionPane.showConfirmDialog(this, panel, "Reset Password",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;

        String newPassword = new String(newPasswordField.getPassword()).trim();
        if (!ValidationUtil.isValidPassword(newPassword)) {
            showError("Password must be at least 4 characters.");
            return;
        }
        userService.resetPassword(id, newPassword);
        JOptionPane.showMessageDialog(this, "Password updated.");
    }

    private void deleteSelected() {
        String id = getSelectedId();
        if (id == null) {
            showError("Please select a user from the table first.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete user " + id + "? This cannot be undone.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        User u = userService.getById(id);
        boolean deleted;
        if (u != null && "DOCTOR".equalsIgnoreCase(u.getRole())) {
            deleted = doctorService.delete(id);
        } else if (u != null && "MEDICAL_MANAGER".equalsIgnoreCase(u.getRole())) {
            deleted = managerService.delete(id);
        } else {
            deleted = userService.delete(id);
        }

        if (deleted) {
            refreshTable();
        } else {
            showError("Could not delete this user.");
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Validation Error", JOptionPane.WARNING_MESSAGE);
    }
}
    
