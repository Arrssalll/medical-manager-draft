/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author dhanj
 */
public class AuditLogger {
    private static AuditLogger instance;
    private static final String LOG_FILE = "data/auditLog.txt";
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private AuditLogger() {
    }

    public static synchronized AuditLogger getInstance() {
        if (instance == null) {
            instance = new AuditLogger();
        }
        return instance;
    }

    public void log(String actorUsername, String action) {
        String timestamp = LocalDateTime.now().format(FORMAT);
        String entry = timestamp + "|" + actorUsername + "|" + action;
        FileManager.appendLine(LOG_FILE, entry);
    }
}
