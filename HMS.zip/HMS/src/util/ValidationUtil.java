/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;
import java.util.regex.Pattern;

/**
 *
 * @author dhanj
 */
public class ValidationUtil {
     private static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_]{4,20}$");

    public static boolean isNotEmpty(String value) {
        return value != null && !value.trim().isEmpty();
    }

    public static boolean isValidUsername(String username) {
        return isNotEmpty(username) && USERNAME_PATTERN.matcher(username.trim()).matches();
    }

    public static boolean isValidPassword(String password) {
        return password != null && password.length() >= 4;
    }

    public static boolean isValidStatus(String status) {
        return "ACTIVE".equalsIgnoreCase(status) || "INACTIVE".equalsIgnoreCase(status);
    }

    public static boolean isValidAmount(String value) {
        if (!isNotEmpty(value)) return false;
        try {
            double amount = Double.parseDouble(value.trim());
            return isValidAmount(amount);
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean isValidAmount(double value) {
        return value >= 0 && value <= 1_000_000;
    }

    public static boolean isValidPercentage(String value) {
        try {
            double pct = Double.parseDouble(value.trim());
            return pct >= 0 && pct <= 100;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isValidRole(String role) {
        if (role == null) return false;
        switch (role.toUpperCase()) {
            case "ADMIN":
            case "MEDICAL_MANAGER":
            case "DOCTOR":
            case "PATIENT":
                return true;
            default:
                return false;
        }
    }
    
}
