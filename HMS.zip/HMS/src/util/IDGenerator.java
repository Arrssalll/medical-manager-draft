/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;
import java.util.List;

/**
 *
 * @author dhanj
 */
public class IDGenerator {
    public static String nextId(String filePath, String prefix, int digitWidth) {
        List<String> lines = FileManager.readLines(filePath);
        int max = 0;
        for (String line : lines) {
            String[] parts = line.split("\\|");
            if (parts.length == 0) continue;
            String id = parts[0].trim();
            if (id.startsWith(prefix)) {
                String numberPart = id.substring(prefix.length());
                try {
                    int num = Integer.parseInt(numberPart);
                    if (num > max) {
                        max = num;
                    }
                } catch (NumberFormatException ignored) {
                }
            }
        }
        int next = max + 1;
        return prefix + String.format("%0" + digitWidth + "d", next);
    }
    
}
