/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author dhanj
 */
public class Doctor extends User {
    
    private String name;
    private String department;
    private String specialty;
    private String managerId;
    
    public Doctor(String userId, String name, String username, String password, String department, String specialty, String managerId, String status) {
        super(userId, username, password, "DOCTOR", status);
        this.name = name;
        this.department = department;
        this.specialty = specialty;
        
        if (managerId == null || managerId.trim().isEmpty()){
            this.managerId = "-";
        }else {
            this.managerId = managerId;
        }
    }
    
    public String getName(){
        return name;
    }
    
    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()){
            this.name = name.trim();
        }
    }
    
    public String getDepartment(){
        return department;
    }
    public void setDepartment(String department) {
        this.department = department;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public String getManagerId() {
        return managerId;
    }

    public void setManagerId(String managerId) {
    if (managerId == null || managerId.trim().isEmpty()) {
        this.managerId = "-";
    } else {
        this.managerId = managerId;
    }
}

    public boolean isAssigned() {
        return !"-".equals(managerId);
    }

    @Override
    public String getDashboardTitle() {
        return "Doctor Dashboard";
    }

    public String toProfileLine() {
        return getUserId() + "|" + name + "|" + getUsername() + "|" + department + "|"
                + specialty + "|" + managerId + "|" + getStatus();
    }

    @Override
    public String toString() {
        return getUserId() + " | " + name + " | " + department + " | " + specialty
                + " | Manager: " + managerId + " | " + getStatus();
    }

}
