package model;

/**
 * Carries the figures shown on the Medical Manager's revenue summary.
 *
 * The numbers are worked out from the billing records kept by the
 * Administrative Staff module. Bills are only read, never changed, because
 * billing belongs to that part of the system.
 *
 * A bill counts as collected once its status is PAID. Bills that are still
 * UNPAID or PENDING are reported separately as money not yet received.
 */
public class RevenueSummary {

    private int totalBills;
    private int paidBills;
    private int pendingBills;
    private int unpaidBills;

    private double totalBilled;
    private double totalCollected;

    public int getTotalBills() {
        return totalBills;
    }

    public void setTotalBills(int totalBills) {
        this.totalBills = totalBills;
    }

    public int getPaidBills() {
        return paidBills;
    }

    public void setPaidBills(int paidBills) {
        this.paidBills = paidBills;
    }

    public int getPendingBills() {
        return pendingBills;
    }

    public void setPendingBills(int pendingBills) {
        this.pendingBills = pendingBills;
    }

    public int getUnpaidBills() {
        return unpaidBills;
    }

    public void setUnpaidBills(int unpaidBills) {
        this.unpaidBills = unpaidBills;
    }

    public double getTotalBilled() {
        return totalBilled;
    }

    public void setTotalBilled(double totalBilled) {
        this.totalBilled = totalBilled;
    }

    public double getTotalCollected() {
        return totalCollected;
    }

    public void setTotalCollected(double totalCollected) {
        this.totalCollected = totalCollected;
    }

    /**
     * Money that has been billed but not yet received.
     */
    public double getOutstanding() {
        return totalBilled - totalCollected;
    }

    public boolean hasBills() {
        return totalBills > 0;
    }
}
