package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Carries the figures shown on the Medical Manager's hospital metrics
 * report.
 *
 * Some parts of the hospital system are built by other members of the group
 * and are not in the project yet. Any figure that cannot be worked out is
 * listed as a missing source instead of being shown as zero, so the report
 * never looks like real data when it is not.
 */
public class HospitalMetrics {

    private int totalDepartments;
    private int activeDepartments;

    private int totalAssessmentTypes;
    private int activeAssessmentTypes;

    private int totalScheduleSlots;
    private int availableSlots;
    private int bookedSlots;
    private int unavailableSlots;

    private int totalDoctors;
    private int assignedDoctors;
    private int doctorsWithSchedules;

    private int totalPatients;

    private final List<String> missingSources = new ArrayList<>();

    public int getTotalDepartments() {
        return totalDepartments;
    }

    public void setTotalDepartments(int totalDepartments) {
        this.totalDepartments = totalDepartments;
    }

    public int getActiveDepartments() {
        return activeDepartments;
    }

    public void setActiveDepartments(int activeDepartments) {
        this.activeDepartments = activeDepartments;
    }

    public int getTotalAssessmentTypes() {
        return totalAssessmentTypes;
    }

    public void setTotalAssessmentTypes(int totalAssessmentTypes) {
        this.totalAssessmentTypes = totalAssessmentTypes;
    }

    public int getActiveAssessmentTypes() {
        return activeAssessmentTypes;
    }

    public void setActiveAssessmentTypes(int activeAssessmentTypes) {
        this.activeAssessmentTypes = activeAssessmentTypes;
    }

    public int getTotalScheduleSlots() {
        return totalScheduleSlots;
    }

    public void setTotalScheduleSlots(int totalScheduleSlots) {
        this.totalScheduleSlots = totalScheduleSlots;
    }

    public int getAvailableSlots() {
        return availableSlots;
    }

    public void setAvailableSlots(int availableSlots) {
        this.availableSlots = availableSlots;
    }

    public int getBookedSlots() {
        return bookedSlots;
    }

    public void setBookedSlots(int bookedSlots) {
        this.bookedSlots = bookedSlots;
    }

    public int getUnavailableSlots() {
        return unavailableSlots;
    }

    public void setUnavailableSlots(int unavailableSlots) {
        this.unavailableSlots = unavailableSlots;
    }

    public int getTotalDoctors() {
        return totalDoctors;
    }

    public void setTotalDoctors(int totalDoctors) {
        this.totalDoctors = totalDoctors;
    }

    public int getAssignedDoctors() {
        return assignedDoctors;
    }

    public void setAssignedDoctors(int assignedDoctors) {
        this.assignedDoctors = assignedDoctors;
    }

    public int getDoctorsWithSchedules() {
        return doctorsWithSchedules;
    }

    public void setDoctorsWithSchedules(int doctorsWithSchedules) {
        this.doctorsWithSchedules = doctorsWithSchedules;
    }

    public int getTotalPatients() {
        return totalPatients;
    }

    public void setTotalPatients(int totalPatients) {
        this.totalPatients = totalPatients;
    }

    /**
     * Notes a figure that cannot be produced because the module that owns
     * the data has not been added to the project yet.
     */
    public void addMissingSource(String description) {
        missingSources.add(description);
    }

    public List<String> getMissingSources() {
        return missingSources;
    }
}
