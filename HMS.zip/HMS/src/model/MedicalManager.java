/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author dhanj
 */
public class MedicalManager extends User {
     private String name;

    public MedicalManager(String userId, String name, String username, String password, String status) {
        super(userId, username, password, "MEDICAL_MANAGER", status);
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name.trim();
        }
    }

    @Override
    public String getDashboardTitle() {
        return "Medical Manager Dashboard";
    }

    public String toProfileLine() {
        return getUserId() + "|" + name + "|" + getUsername() + "|" + getStatus();
    }

    @Override
    public String toString() {
        return getUserId() + " | " + name + " | " + getStatus();
    }
    
}
