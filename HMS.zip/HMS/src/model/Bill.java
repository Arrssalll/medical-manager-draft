/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author dhanj
 */
public class Bill {
        public static final String[] VALID_STATUSES = {"UNPAID", "PENDING", "PAID"};

    private String billId;
    private String patientId;
    private double amount;
    private String status;

    public Bill(String billId, String patientId, double amount, String status) {
        this.billId = billId;
        this.patientId = patientId;
        this.amount = amount;
        this.status = status;
    }

    public String getBillId() {
        return billId;
    }

    public String getPatientId() {
        return patientId;
    }

    public double getAmount() {
        return amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String toFileLine() {
        return billId + "|" + patientId + "|" + amount + "|" + status;
    }

    @Override
    public String toString() {
        return billId + " | Patient: " + patientId + " | RM " + String.format("%.2f", amount) + " | " + status;
    }

    
}
