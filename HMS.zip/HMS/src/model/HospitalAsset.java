/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author dhanj
 */
public class HospitalAsset {
    public static final String[] VALID_TYPES = {"WARD", "CLINIC", "LAB", "IMAGING_ROOM"};

    private String assetId;
    private String type;
    private String name;
    private String location;
    private String status;

    public HospitalAsset(String assetId, String type, String name, String location, String status) {
        this.assetId = assetId;
        this.type = type;
        this.name = name;
        this.location = location;
        this.status = status;
    }

    public String getAssetId() {
        return assetId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String toFileLine() {
        return assetId + "|" + type + "|" + name + "|" + location + "|" + status;
    }

    @Override
    public String toString() {
        return assetId + " | " + type + " | " + name + " | " + location + " | " + status;
    }
    
}
