/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author dhanj
 */
public class InsuranceNetwork {
    
    private String insuranceId;
    private String providerName;
    private double coveragePercentage;
    private String status;

    public InsuranceNetwork(String insuranceId, String providerName, double coveragePercentage, String status) {
        this.insuranceId = insuranceId;
        this.providerName = providerName;
        this.coveragePercentage = coveragePercentage;
        this.status = status;
    }

    public String getInsuranceId() {
        return insuranceId;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public double getCoveragePercentage() {
        return coveragePercentage;
    }

    public void setCoveragePercentage(double coveragePercentage) {
        this.coveragePercentage = coveragePercentage;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String toFileLine() {
        return insuranceId + "|" + providerName + "|" + coveragePercentage + "|" + status;
    }

    @Override
    public String toString() {
        return insuranceId + " | " + providerName + " | " + coveragePercentage + "% | " + status;
    }
    
}
