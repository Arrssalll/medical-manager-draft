/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author dhanj
 */
public class ConsultationRate {
     private String rateId;
    private String departmentOrType;
    private double amount;
    private String status;

    public ConsultationRate(String rateId, String departmentOrType, double amount, String status) {
        this.rateId = rateId;
        this.departmentOrType = departmentOrType;
        this.amount = amount;
        this.status = status;
    }

    public String getRateId() {
        return rateId;
    }

    public String getDepartmentOrType() {
        return departmentOrType;
    }

    public void setDepartmentOrType(String departmentOrType) {
        this.departmentOrType = departmentOrType;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String toFileLine() {
        return rateId + "|" + departmentOrType + "|" + amount + "|" + status;
    }

    @Override
    public String toString() {
        return rateId + " | " + departmentOrType + " | RM " + String.format("%.2f", amount) + " | " + status;
    }
    
    
}
