/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author dhanj
 */
public class Patient extends User{
    public Patient(String userId, String username, String password, String status) {
        super(userId, username, password, "PATIENT", status);
    }
    
    @Override
    public String getDashboardTitle(){
        return "Patient Dashboard";
    }
    
}
