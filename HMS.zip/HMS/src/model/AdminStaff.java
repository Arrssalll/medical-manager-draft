/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author dhanj
 */
public class AdminStaff extends User{
    private String department;
    
    public AdminStaff(String userId, String username, String password, String status) {
        super(userId, username, password, "ADMIN", status);
        this.department = "Administration";
    }
    
    public String getDepartment() {
        return department;
    }
    
    public void setDepartment(String department) {
        this.department = department;
    }
    
    @Override
    public String getDashboardTitle(){
        return "Administrative Staff Dashboard";
    }
}
