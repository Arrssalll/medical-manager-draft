/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author dhanj
 */
public abstract class User {

    private String userId;
    private String username;
    private String password;
    private final String role;
    private String status;

    public User(String userId, String username, String password, String role, String status) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.role = role;
        this.status = status;
    }
        public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        if (username != null && !username.trim().isEmpty()) {
            this.username = username.trim();
        }
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if (password != null && password.length() >= 4) {
            this.password = password;
        }
    }

    public String getRole() {
        return role;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        if (status != null && (status.equalsIgnoreCase("ACTIVE") || status.equalsIgnoreCase("INACTIVE"))) {
            this.status = status.toUpperCase();
        }
    }

    public boolean isActive() {
        return "ACTIVE".equalsIgnoreCase(status);
    }

    public abstract String getDashboardTitle();

    public String toFileLine() {
        return userId + "|" + username + "|" + password + "|" + role + "|" + status;
    }

    @Override
    public String toString() {
        return userId + " (" + username + ") - " + role + " - " + status;
    }
    
    
}
    

