/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import model.Doctor;
import util.FileManager;
import util.IDGenerator;
import util.AuditLogger;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author dhanj
 */
public class DoctorService implements CrudService<Doctor> {

    private static final String DOCTORS_FILE = "data/doctors.txt";
    private static final String USERS_FILE = "data/users.txt";

    private Doctor fromLine(String line) {
        String[] p = line.split("\\|");
        if (p.length < 7) return null;
        return new Doctor(p[0], p[1], p[2], "----", p[3], p[4], p[5], p[6]);
    }

    @Override
    public List<Doctor> getAll() {
        List<Doctor> doctors = new ArrayList<>();
        for (String line : FileManager.readLines(DOCTORS_FILE)) {
            Doctor d = fromLine(line);
            if (d != null) doctors.add(d);
        }
        return doctors;
    }

    @Override
    public Doctor getById(String id) {
        for (Doctor d : getAll()) {
            if (d.getUserId().equalsIgnoreCase(id)) return d;
        }
        return null;
    }

    public Doctor createDoctor(String name, String username, String password,
                                String department, String specialty, String status) {
        UserManagementService userService = new UserManagementService();
        if (userService.isUsernameTaken(username)) return null;

        String newId = IDGenerator.nextId(DOCTORS_FILE, "D", 3);
        Doctor doctor = new Doctor(newId, name, username, password, department, specialty, "-", status);

        FileManager.appendLine(USERS_FILE, newId + "|" + username + "|" + password + "|DOCTOR|" + status);
        FileManager.appendLine(DOCTORS_FILE, doctor.toProfileLine());

        AuditLogger.getInstance().log("SYSTEM", "Created doctor " + newId + " (" + name + ")");
        return doctor;
    }

    @Override
    public boolean add(Doctor item) {
        if (item == null) return false;
        FileManager.appendLine(DOCTORS_FILE, item.toProfileLine());
        return true;
    }

    @Override
    public boolean update(String id, Doctor updatedItem) {
        List<String> lines = FileManager.readLines(DOCTORS_FILE);
        List<String> result = new ArrayList<>();
        boolean found = false;
        for (String line : lines) {
            String[] p = line.split("\\|");
            if (p.length >= 1 && p[0].equalsIgnoreCase(id)) {
                result.add(updatedItem.toProfileLine());
                found = true;
            } else {
                result.add(line);
            }
        }
        if (found) {
            FileManager.writeLines(DOCTORS_FILE, result);
            AuditLogger.getInstance().log("SYSTEM", "Updated doctor profile " + id);
        }
        return found;
    }

    public boolean assignManager(String doctorId, String managerId) {
        Doctor d = getById(doctorId);
        if (d == null) return false;
        d.setManagerId(managerId);
        boolean ok = update(doctorId, d);
        if (ok) {
            AuditLogger.getInstance().log("SYSTEM", "Assigned doctor " + doctorId + " to manager " + managerId);
        }
        return ok;
    }

    @Override
    public boolean delete(String id) {
        List<String> lines = FileManager.readLines(DOCTORS_FILE);
        List<String> result = new ArrayList<>();
        boolean found = false;
        for (String line : lines) {
            String[] p = line.split("\\|");
            if (p.length >= 1 && p[0].equalsIgnoreCase(id)) {
                found = true;
            } else {
                result.add(line);
            }
        }
        if (found) {
            FileManager.writeLines(DOCTORS_FILE, result);
            new UserManagementService().delete(id);
            AuditLogger.getInstance().log("SYSTEM", "Deleted doctor " + id);
        }
        return found;
    }
}