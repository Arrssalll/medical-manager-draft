/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import model.Bill;
import util.FileManager;
import util.AuditLogger;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dhanj
 */
public class BillService {
private static final String BILLS_FILE = "data/bills.txt";

    private Bill fromLine(String line) {
        String[] p = line.split("\\|");
        if (p.length < 4) return null;
        try {
            return new Bill(p[0], p[1], Double.parseDouble(p[2]), p[3]);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public List<Bill> getAll() {
        List<Bill> bills = new ArrayList<>();
        for (String line : FileManager.readLines(BILLS_FILE)) {
            Bill b = fromLine(line);
            if (b != null) bills.add(b);
        }
        return bills;
    }

    public Bill getById(String id) {
        for (Bill b : getAll()) {
            if (b.getBillId().equalsIgnoreCase(id)) return b;
        }
        return null;
    }

    public boolean updateStatus(String billId, String newStatus) {
        List<String> lines = FileManager.readLines(BILLS_FILE);
        List<String> result = new ArrayList<>();
        boolean found = false;
        for (String line : lines) {
            String[] p = line.split("\\|");
            if (p.length >= 1 && p[0].equalsIgnoreCase(billId)) {
                Bill b = fromLine(line);
                if (b != null) {
                    b.setStatus(newStatus);
                    result.add(b.toFileLine());
                    found = true;
                    continue;
                }
            }
            result.add(line);
        }
        if (found) {
            FileManager.writeLines(BILLS_FILE, result);
            AuditLogger.getInstance().log("SYSTEM", "Updated bill " + billId + " status to " + newStatus);
        }
        return found;
    }
}