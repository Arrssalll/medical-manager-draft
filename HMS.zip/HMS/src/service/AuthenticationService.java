/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import util.FileManager;
import java.util.List;

/**
 *
 * @author dhanj
 */
public class AuthenticationService {
    private static final String USERS_FILE = "data/users.txt";

    public static class AuthResult {
        public final boolean success;
        public final String userId;
        public final String username;
        public final String role;
        public final String message;

        public AuthResult(boolean success, String userId, String username, String role, String message) {
            this.success = success;
            this.userId = userId;
            this.username = username;
            this.role = role;
            this.message = message;
        }
    }

    public AuthResult authenticate(String username, String password) {
        List<String> lines = FileManager.readLines(USERS_FILE);
        for (String line : lines) {
            String[] parts = line.split("\\|");
            if (parts.length < 5) continue;
            String id = parts[0];
            String user = parts[1];
            String pass = parts[2];
            String role = parts[3];
            String status = parts[4];

            if (user.equalsIgnoreCase(username)) {
                if (!pass.equals(password)) {
                    return new AuthResult(false, null, null, null, "Incorrect password.");
                }
                if (!"ACTIVE".equalsIgnoreCase(status)) {
                    return new AuthResult(false, null, null, null, "This account is INACTIVE. Contact the administrator.");
                }
                return new AuthResult(true, id, user, role, "Login successful.");
            }
        }
        return new AuthResult(false, null, null, null, "Username not found.");
    }
    
}
