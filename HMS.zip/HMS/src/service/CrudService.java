/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;
import java.util.List;

/**
 *
 * @author dhanj
 */
public interface CrudService<T> {
  List<T> getAll();

    T getById(String id);

    boolean add(T item);

    boolean update(String id, T updatedItem);

    boolean delete(String id);
  
    
}
