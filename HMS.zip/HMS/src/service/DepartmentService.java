package service;

import model.Department;
import util.FileManager;
import util.IDGenerator;
import util.ValidationUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Handles the clinical departments looked after by the Medical Manager.
 *
 * Reading and writing goes through the shared FileManager, and new
 * identifiers come from the shared IDGenerator, so departments are stored
 * the same way as every other record in the system.
 *
 * Departments are retired by setting their status to INACTIVE instead of
 * being removed, because a doctor record may still name the department.
 */
public class DepartmentService {

    private static final String DEPARTMENTS_FILE = "data/departments.txt";
    private static final String ID_PREFIX = "DEP";
    private static final int ID_DIGITS = 3;

    private Department fromLine(String line) {
        String[] parts = line.split("\\|");
        if (parts.length < 4) {
            return null;
        }
        try {
            return new Department(parts[0], parts[1], parts[2], parts[3]);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /**
     * Returns every stored department. A record that cannot be read is
     * skipped so one bad line does not stop the whole list from loading.
     */
    public List<Department> getAllDepartments() {
        List<Department> departments = new ArrayList<>();
        for (String line : FileManager.readLines(DEPARTMENTS_FILE)) {
            Department department = fromLine(line);
            if (department != null) {
                departments.add(department);
            }
        }
        return departments;
    }

    public Department findDepartmentById(String departmentId) {
        if (!ValidationUtil.isNotEmpty(departmentId)) {
            throw new IllegalArgumentException("Please enter a department ID.");
        }
        for (Department department : getAllDepartments()) {
            if (department.getDepartmentID().equalsIgnoreCase(departmentId.trim())) {
                return department;
            }
        }
        return null;
    }

    /**
     * Adds a department and gives it the next DEP identifier.
     * New departments always start ACTIVE.
     */
    public Department addDepartment(String departmentName, String specialty) {
        if (!ValidationUtil.isNotEmpty(departmentName) || !ValidationUtil.isNotEmpty(specialty)) {
            throw new IllegalArgumentException("Please fill in all required fields.");
        }
        if (isNameTaken(departmentName, null)) {
            throw new IllegalArgumentException(
                    "A department named '" + departmentName.trim() + "' already exists.");
        }

        String newId = IDGenerator.nextId(DEPARTMENTS_FILE, ID_PREFIX, ID_DIGITS);
        Department department = new Department(newId, departmentName, specialty, Department.STATUS_ACTIVE);
        FileManager.appendLine(DEPARTMENTS_FILE, department.toFileString());
        return department;
    }

    /**
     * Saves new details for an existing department. Every other record in
     * the file is written back unchanged.
     */
    public Department updateDepartment(String departmentId, String departmentName,
                                       String specialty, String status) {
        if (!ValidationUtil.isNotEmpty(departmentName) || !ValidationUtil.isNotEmpty(specialty)) {
            throw new IllegalArgumentException("Please fill in all required fields.");
        }
        if (!ValidationUtil.isValidStatus(status)) {
            throw new IllegalArgumentException("Please select a valid status.");
        }

        Department existing = findDepartmentById(departmentId);
        if (existing == null) {
            throw new IllegalArgumentException("Record not found: " + departmentId);
        }
        if (isNameTaken(departmentName, existing.getDepartmentID())) {
            throw new IllegalArgumentException(
                    "A department named '" + departmentName.trim() + "' already exists.");
        }

        Department updated = new Department(existing.getDepartmentID(), departmentName,
                specialty, status.toUpperCase());

        List<String> rewritten = new ArrayList<>();
        for (String line : FileManager.readLines(DEPARTMENTS_FILE)) {
            String[] parts = line.split("\\|");
            if (parts.length >= 1 && parts[0].equalsIgnoreCase(updated.getDepartmentID())) {
                rewritten.add(updated.toFileString());
            } else {
                rewritten.add(line);
            }
        }
        FileManager.writeLines(DEPARTMENTS_FILE, rewritten);
        return updated;
    }

    /**
     * Checks whether another department already uses this name.
     * The department being edited is skipped by passing its own ID.
     */
    private boolean isNameTaken(String departmentName, String idToSkip) {
        String wanted = departmentName.trim();
        for (Department department : getAllDepartments()) {
            if (idToSkip != null && department.getDepartmentID().equalsIgnoreCase(idToSkip)) {
                continue;
            }
            if (department.getDepartmentName().equalsIgnoreCase(wanted)) {
                return true;
            }
        }
        return false;
    }
}
