package service;

import model.AssessmentType;
import util.FileManager;
import util.IDGenerator;
import util.ValidationUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Handles the assessment and check-up types that doctors pick from when
 * they record a consultation.
 *
 * The Medical Manager keeps this list up to date. Choosing a type during a
 * consultation belongs to the Doctor part of the system.
 *
 * A type that is no longer offered is set to INACTIVE rather than removed,
 * so older consultation records still make sense.
 */
public class AssessmentTypeService {

    private static final String TYPES_FILE = "data/assessmentTypes.txt";
    private static final String ID_PREFIX = "AT";
    private static final int ID_DIGITS = 3;

    private AssessmentType fromLine(String line) {
        String[] parts = line.split("\\|");
        if (parts.length < 4) {
            return null;
        }
        try {
            return new AssessmentType(parts[0], parts[1], parts[2], parts[3]);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public List<AssessmentType> getAllAssessmentTypes() {
        List<AssessmentType> types = new ArrayList<>();
        for (String line : FileManager.readLines(TYPES_FILE)) {
            AssessmentType type = fromLine(line);
            if (type != null) {
                types.add(type);
            }
        }
        return types;
    }

    public AssessmentType findAssessmentTypeById(String typeId) {
        if (!ValidationUtil.isNotEmpty(typeId)) {
            throw new IllegalArgumentException("Please enter an assessment type ID.");
        }
        for (AssessmentType type : getAllAssessmentTypes()) {
            if (type.getAssessmentTypeID().equalsIgnoreCase(typeId.trim())) {
                return type;
            }
        }
        return null;
    }

    /**
     * Adds a new assessment type with the next AT identifier.
     * New types always start ACTIVE.
     */
    public AssessmentType addAssessmentType(String assessmentName, String description) {
        if (!ValidationUtil.isNotEmpty(assessmentName) || !ValidationUtil.isNotEmpty(description)) {
            throw new IllegalArgumentException("Please fill in all required fields.");
        }
        if (isNameTaken(assessmentName, null)) {
            throw new IllegalArgumentException(
                    "An assessment type named '" + assessmentName.trim() + "' already exists.");
        }

        String newId = IDGenerator.nextId(TYPES_FILE, ID_PREFIX, ID_DIGITS);
        AssessmentType type = new AssessmentType(newId, assessmentName, description,
                AssessmentType.STATUS_ACTIVE);
        FileManager.appendLine(TYPES_FILE, type.toFileString());
        return type;
    }

    public AssessmentType updateAssessmentType(String typeId, String assessmentName,
                                               String description, String status) {
        if (!ValidationUtil.isNotEmpty(assessmentName) || !ValidationUtil.isNotEmpty(description)) {
            throw new IllegalArgumentException("Please fill in all required fields.");
        }
        if (!ValidationUtil.isValidStatus(status)) {
            throw new IllegalArgumentException("Please select a valid status.");
        }

        AssessmentType existing = findAssessmentTypeById(typeId);
        if (existing == null) {
            throw new IllegalArgumentException("Record not found: " + typeId);
        }
        if (isNameTaken(assessmentName, existing.getAssessmentTypeID())) {
            throw new IllegalArgumentException(
                    "An assessment type named '" + assessmentName.trim() + "' already exists.");
        }

        AssessmentType updated = new AssessmentType(existing.getAssessmentTypeID(), assessmentName,
                description, status.toUpperCase());

        List<String> rewritten = new ArrayList<>();
        for (String line : FileManager.readLines(TYPES_FILE)) {
            String[] parts = line.split("\\|");
            if (parts.length >= 1 && parts[0].equalsIgnoreCase(updated.getAssessmentTypeID())) {
                rewritten.add(updated.toFileString());
            } else {
                rewritten.add(line);
            }
        }
        FileManager.writeLines(TYPES_FILE, rewritten);
        return updated;
    }

    private boolean isNameTaken(String assessmentName, String idToSkip) {
        String wanted = assessmentName.trim();
        for (AssessmentType type : getAllAssessmentTypes()) {
            if (idToSkip != null && type.getAssessmentTypeID().equalsIgnoreCase(idToSkip)) {
                continue;
            }
            if (type.getAssessmentName().equalsIgnoreCase(wanted)) {
                return true;
            }
        }
        return false;
    }
}
