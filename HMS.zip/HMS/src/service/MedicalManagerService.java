/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import model.MedicalManager;
import util.FileManager;
import util.IDGenerator;
import util.AuditLogger;

import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author dhanj
 */
public class MedicalManagerService implements CrudService<MedicalManager> {

    private static final String MANAGERS_FILE = "data/medicalManagers.txt";
    private static final String USERS_FILE = "data/users.txt";

    private MedicalManager fromLine(String line) {
        String[] p = line.split("\\|");
        if (p.length < 4) return null;
        return new MedicalManager(p[0], p[1], p[2], "----", p[3]);
    }

    @Override
    public List<MedicalManager> getAll() {
        List<MedicalManager> managers = new ArrayList<>();
        for (String line : FileManager.readLines(MANAGERS_FILE)) {
            MedicalManager m = fromLine(line);
            if (m != null) managers.add(m);
        }
        return managers;
    }

    @Override
    public MedicalManager getById(String id) {
        for (MedicalManager m : getAll()) {
            if (m.getUserId().equalsIgnoreCase(id)) return m;
        }
        return null;
    }

    public MedicalManager createManager(String name, String username, String password, String status) {
        UserManagementService userService = new UserManagementService();
        if (userService.isUsernameTaken(username)) return null;

        String newId = IDGenerator.nextId(MANAGERS_FILE, "M", 3);
        MedicalManager manager = new MedicalManager(newId, name, username, password, status);

        FileManager.appendLine(USERS_FILE, newId + "|" + username + "|" + password + "|MEDICAL_MANAGER|" + status);
        FileManager.appendLine(MANAGERS_FILE, manager.toProfileLine());

        AuditLogger.getInstance().log("SYSTEM", "Created medical manager " + newId + " (" + name + ")");
        return manager;
    }

    @Override
    public boolean add(MedicalManager item) {
        if (item == null) return false;
        FileManager.appendLine(MANAGERS_FILE, item.toProfileLine());
        return true;
    }

    @Override
    public boolean update(String id, MedicalManager updatedItem) {
        List<String> lines = FileManager.readLines(MANAGERS_FILE);
        List<String> result = new ArrayList<>();
        boolean found = false;
        for (String line : lines) {
            String[] p = line.split("\\|");
            if (p.length >= 1 && p[0].equalsIgnoreCase(id)) {
                result.add(updatedItem.toProfileLine());
                found = true;
            } else {
                result.add(line);
            }
        }
        if (found) {
            FileManager.writeLines(MANAGERS_FILE, result);
            AuditLogger.getInstance().log("SYSTEM", "Updated medical manager " + id);
        }
        return found;
    }

    @Override
    public boolean delete(String id) {
        List<String> lines = FileManager.readLines(MANAGERS_FILE);
        List<String> result = new ArrayList<>();
        boolean found = false;
        for (String line : lines) {
            String[] p = line.split("\\|");
            if (p.length >= 1 && p[0].equalsIgnoreCase(id)) {
                found = true;
            } else {
                result.add(line);
            }
        }
        if (found) {
            FileManager.writeLines(MANAGERS_FILE, result);
            new UserManagementService().delete(id);
            AuditLogger.getInstance().log("SYSTEM", "Deleted medical manager " + id);
        }
        return found;
    }
}
