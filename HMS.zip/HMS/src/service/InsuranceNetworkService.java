/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import model.InsuranceNetwork;
import util.FileManager;
import util.IDGenerator;
import util.AuditLogger;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dhanj
 */
public class InsuranceNetworkService implements CrudService<InsuranceNetwork> {

    private static final String INSURANCE_FILE = "data/insuranceNetworks.txt";

    private InsuranceNetwork fromLine(String line) {
        String[] p = line.split("\\|");
        if (p.length < 4) return null;
        try {
            return new InsuranceNetwork(p[0], p[1], Double.parseDouble(p[2]), p[3]);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    public List<InsuranceNetwork> getAll() {
        List<InsuranceNetwork> list = new ArrayList<>();
        for (String line : FileManager.readLines(INSURANCE_FILE)) {
            InsuranceNetwork i = fromLine(line);
            if (i != null) list.add(i);
        }
        return list;
    }

    @Override
    public InsuranceNetwork getById(String id) {
        for (InsuranceNetwork i : getAll()) {
            if (i.getInsuranceId().equalsIgnoreCase(id)) return i;
        }
        return null;
    }

    public InsuranceNetwork createInsurance(String providerName, double coveragePercentage, String status) {
        String newId = IDGenerator.nextId(INSURANCE_FILE, "INS", 3);
        InsuranceNetwork ins = new InsuranceNetwork(newId, providerName, coveragePercentage, status);
        FileManager.appendLine(INSURANCE_FILE, ins.toFileLine());
        AuditLogger.getInstance().log("SYSTEM", "Created insurance network " + newId);
        return ins;
    }

    @Override
    public boolean add(InsuranceNetwork item) {
        if (item == null) return false;
        FileManager.appendLine(INSURANCE_FILE, item.toFileLine());
        return true;
    }

    @Override
    public boolean update(String id, InsuranceNetwork updatedItem) {
        List<String> lines = FileManager.readLines(INSURANCE_FILE);
        List<String> result = new ArrayList<>();
        boolean found = false;
        for (String line : lines) {
            String[] p = line.split("\\|");
            if (p.length >= 1 && p[0].equalsIgnoreCase(id)) {
                result.add(updatedItem.toFileLine());
                found = true;
            } else {
                result.add(line);
            }
        }
        if (found) {
            FileManager.writeLines(INSURANCE_FILE, result);
            AuditLogger.getInstance().log("SYSTEM", "Updated insurance network " + id);
        }
        return found;
    }

    @Override
    public boolean delete(String id) {
        List<String> lines = FileManager.readLines(INSURANCE_FILE);
        List<String> result = new ArrayList<>();
        boolean found = false;
        for (String line : lines) {
            String[] p = line.split("\\|");
            if (p.length >= 1 && p[0].equalsIgnoreCase(id)) {
                found = true;
            } else {
                result.add(line);
            }
        }
        if (found) {
            FileManager.writeLines(INSURANCE_FILE, result);
            AuditLogger.getInstance().log("SYSTEM", "Deleted insurance network " + id);
        }
        return found;
    }
}