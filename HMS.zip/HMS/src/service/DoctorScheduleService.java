package service;

import model.DoctorSchedule;
import util.FileManager;
import util.IDGenerator;
import util.ValidationUtil;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles the working schedules and bookable slots the Medical Manager
 * prepares for each doctor.
 *
 * The doctor named on a slot is checked against the doctor records kept by
 * the Administrative Staff module, so a roster cannot be built for someone
 * who does not work here.
 *
 * Booking a slot for a patient is not done here. This service only builds
 * and adjusts the roster itself.
 */
public class DoctorScheduleService {

    private static final String SCHEDULES_FILE = "data/doctorSchedules.txt";
    private static final String ID_PREFIX = "SCH";
    private static final int ID_DIGITS = 3;

    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm");

    private final DoctorService doctorService = new DoctorService();

    private DoctorSchedule fromLine(String line) {
        String[] parts = line.split("\\|");
        if (parts.length < 6) {
            return null;
        }
        try {
            return new DoctorSchedule(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5]);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public List<DoctorSchedule> getAllSchedules() {
        List<DoctorSchedule> schedules = new ArrayList<>();
        for (String line : FileManager.readLines(SCHEDULES_FILE)) {
            DoctorSchedule schedule = fromLine(line);
            if (schedule != null) {
                schedules.add(schedule);
            }
        }
        return schedules;
    }

    public DoctorSchedule findScheduleById(String scheduleId) {
        if (!ValidationUtil.isNotEmpty(scheduleId)) {
            throw new IllegalArgumentException("Please enter a schedule ID.");
        }
        for (DoctorSchedule schedule : getAllSchedules()) {
            if (schedule.getScheduleID().equalsIgnoreCase(scheduleId.trim())) {
                return schedule;
            }
        }
        return null;
    }

    public List<DoctorSchedule> getSchedulesByDoctor(String doctorId) {
        if (!ValidationUtil.isNotEmpty(doctorId)) {
            throw new IllegalArgumentException("Please enter a doctor ID.");
        }
        List<DoctorSchedule> found = new ArrayList<>();
        for (DoctorSchedule schedule : getAllSchedules()) {
            if (schedule.getDoctorID().equalsIgnoreCase(doctorId.trim())) {
                found.add(schedule);
            }
        }
        return found;
    }

    public List<DoctorSchedule> getAvailableSchedules() {
        List<DoctorSchedule> found = new ArrayList<>();
        for (DoctorSchedule schedule : getAllSchedules()) {
            if (DoctorSchedule.STATUS_AVAILABLE.equals(schedule.getStatus())) {
                found.add(schedule);
            }
        }
        return found;
    }

    /**
     * Adds a slot to a doctor's roster. New slots always start AVAILABLE so
     * a patient can book them.
     */
    public DoctorSchedule addSchedule(String doctorId, String date, String startTime, String endTime) {
        requireKnownDoctor(doctorId);

        // Building the object first runs the date, time and ordering checks
        // held inside DoctorSchedule before anything is written.
        DoctorSchedule candidate = new DoctorSchedule(doctorId.trim(), date, startTime, endTime);
        requireNoClash(candidate, null);

        String newId = IDGenerator.nextId(SCHEDULES_FILE, ID_PREFIX, ID_DIGITS);
        candidate.setScheduleID(newId);
        FileManager.appendLine(SCHEDULES_FILE, candidate.toFileString());
        return candidate;
    }

    /**
     * Saves new details for an existing slot. The doctor on a slot is not
     * changed here; a slot for a different doctor should be added instead.
     */
    public DoctorSchedule updateSchedule(String scheduleId, String date, String startTime,
                                         String endTime, String status) {
        DoctorSchedule existing = findScheduleById(scheduleId);
        if (existing == null) {
            throw new IllegalArgumentException("Record not found: " + scheduleId);
        }

        DoctorSchedule updated = new DoctorSchedule(existing.getScheduleID(), existing.getDoctorID(),
                date, startTime, endTime, status);
        requireNoClash(updated, existing.getScheduleID());

        List<String> rewritten = new ArrayList<>();
        for (String line : FileManager.readLines(SCHEDULES_FILE)) {
            String[] parts = line.split("\\|");
            if (parts.length >= 1 && parts[0].equalsIgnoreCase(updated.getScheduleID())) {
                rewritten.add(updated.toFileString());
            } else {
                rewritten.add(line);
            }
        }
        FileManager.writeLines(SCHEDULES_FILE, rewritten);
        return updated;
    }

    /**
     * Confirms the doctor exists in the shared doctor records before a
     * roster is built for them.
     */
    private void requireKnownDoctor(String doctorId) {
        if (!ValidationUtil.isNotEmpty(doctorId)) {
            throw new IllegalArgumentException("Please enter a doctor ID.");
        }
        if (doctorService.getById(doctorId.trim()) == null) {
            throw new IllegalArgumentException("No doctor found with ID " + doctorId.trim()
                    + ". Doctor accounts are created by Administrative Staff.");
        }
    }

    /**
     * Rejects a slot that would sit on top of another slot already given to
     * the same doctor on the same day. The slot being edited is skipped so
     * it is not treated as clashing with itself.
     */
    private void requireNoClash(DoctorSchedule candidate, String idToSkip) {
        LocalDate candidateDay = LocalDate.parse(candidate.getDate());
        LocalTime candidateStart = LocalTime.parse(candidate.getStartTime(), TIME_FORMAT);
        LocalTime candidateEnd = LocalTime.parse(candidate.getEndTime(), TIME_FORMAT);

        for (DoctorSchedule other : getAllSchedules()) {
            if (idToSkip != null && other.getScheduleID().equalsIgnoreCase(idToSkip)) {
                continue;
            }
            if (!other.getDoctorID().equalsIgnoreCase(candidate.getDoctorID())) {
                continue;
            }
            if (!LocalDate.parse(other.getDate()).equals(candidateDay)) {
                continue;
            }

            LocalTime otherStart = LocalTime.parse(other.getStartTime(), TIME_FORMAT);
            LocalTime otherEnd = LocalTime.parse(other.getEndTime(), TIME_FORMAT);

            if (candidateStart.isBefore(otherEnd) && otherStart.isBefore(candidateEnd)) {
                throw new IllegalArgumentException("Doctor " + candidate.getDoctorID()
                        + " already has an overlapping schedule on " + candidate.getDate()
                        + " (" + other.getScheduleID() + ": " + other.getStartTime()
                        + " to " + other.getEndTime() + ").");
            }
        }
    }
}
