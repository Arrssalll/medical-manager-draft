package service;

import model.AssessmentType;
import model.Bill;
import model.Department;
import model.Doctor;
import model.DoctorSchedule;
import model.HospitalMetrics;
import model.RevenueSummary;
import model.User;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Produces the Medical Manager's analytical reports.
 *
 * Everything here only reads. There is no method that adds, changes or
 * removes a record, which makes the reports safe to run over files owned by
 * the other members of the group.
 *
 * Figures are taken from the services that already understand each kind of
 * record, rather than by pulling the text files apart again in this class.
 */
public class ReportService {

    private final DepartmentService departmentService = new DepartmentService();
    private final AssessmentTypeService assessmentTypeService = new AssessmentTypeService();
    private final DoctorScheduleService scheduleService = new DoctorScheduleService();
    private final DoctorService doctorService = new DoctorService();
    private final UserManagementService userService = new UserManagementService();
    private final BillService billService = new BillService();

    /**
     * Collects the figures for the hospital metrics report.
     */
    public HospitalMetrics getHospitalMetrics() {
        HospitalMetrics metrics = new HospitalMetrics();

        countDepartments(metrics);
        countAssessmentTypes(metrics);
        countSchedules(metrics);
        countDoctors(metrics);
        countPatients(metrics);

        // Parts of the hospital that other members are still building.
        noteIfMissing(metrics, "data/appointments.txt",
                "Appointments booked (appointments.txt - Patient module)");
        noteIfMissing(metrics, "data/medicalRecords.txt",
                "Medical assessments recorded (medicalRecords.txt - Doctor module)");
        noteIfMissing(metrics, "data/feedback.txt",
                "Patient feedback ratings (feedback.txt - Patient module)");

        return metrics;
    }

    /**
     * Adds up the billing records to produce the revenue summary.
     */
    public RevenueSummary getRevenueSummary() {
        RevenueSummary summary = new RevenueSummary();

        int paid = 0;
        int pending = 0;
        int unpaid = 0;
        double billed = 0.0;
        double collected = 0.0;

        List<Bill> bills = billService.getAll();
        for (Bill bill : bills) {
            billed = billed + bill.getAmount();

            if ("PAID".equalsIgnoreCase(bill.getStatus())) {
                paid++;
                collected = collected + bill.getAmount();
            } else if ("PENDING".equalsIgnoreCase(bill.getStatus())) {
                pending++;
            } else {
                unpaid++;
            }
        }

        summary.setTotalBills(bills.size());
        summary.setPaidBills(paid);
        summary.setPendingBills(pending);
        summary.setUnpaidBills(unpaid);
        summary.setTotalBilled(billed);
        summary.setTotalCollected(collected);
        return summary;
    }

    private void countDepartments(HospitalMetrics metrics) {
        List<Department> departments = departmentService.getAllDepartments();
        int active = 0;
        for (Department department : departments) {
            if (Department.STATUS_ACTIVE.equals(department.getStatus())) {
                active++;
            }
        }
        metrics.setTotalDepartments(departments.size());
        metrics.setActiveDepartments(active);
    }

    private void countAssessmentTypes(HospitalMetrics metrics) {
        List<AssessmentType> types = assessmentTypeService.getAllAssessmentTypes();
        int active = 0;
        for (AssessmentType type : types) {
            if (AssessmentType.STATUS_ACTIVE.equals(type.getStatus())) {
                active++;
            }
        }
        metrics.setTotalAssessmentTypes(types.size());
        metrics.setActiveAssessmentTypes(active);
    }

    private void countSchedules(HospitalMetrics metrics) {
        List<DoctorSchedule> schedules = scheduleService.getAllSchedules();
        List<String> seenDoctors = new ArrayList<>();
        int available = 0;
        int booked = 0;
        int unavailable = 0;

        for (DoctorSchedule schedule : schedules) {
            String doctorId = schedule.getDoctorID().toUpperCase();
            if (!seenDoctors.contains(doctorId)) {
                seenDoctors.add(doctorId);
            }

            if (DoctorSchedule.STATUS_AVAILABLE.equals(schedule.getStatus())) {
                available++;
            } else if (DoctorSchedule.STATUS_BOOKED.equals(schedule.getStatus())) {
                booked++;
            } else {
                unavailable++;
            }
        }

        metrics.setTotalScheduleSlots(schedules.size());
        metrics.setAvailableSlots(available);
        metrics.setBookedSlots(booked);
        metrics.setUnavailableSlots(unavailable);
        metrics.setDoctorsWithSchedules(seenDoctors.size());
    }

    private void countDoctors(HospitalMetrics metrics) {
        List<Doctor> doctors = doctorService.getAll();
        int assigned = 0;
        for (Doctor doctor : doctors) {
            if (doctor.isAssigned()) {
                assigned++;
            }
        }
        metrics.setTotalDoctors(doctors.size());
        metrics.setAssignedDoctors(assigned);
    }

    private void countPatients(HospitalMetrics metrics) {
        int patients = 0;
        for (User user : userService.getAll()) {
            if ("PATIENT".equalsIgnoreCase(user.getRole())) {
                patients++;
            }
        }
        metrics.setTotalPatients(patients);
    }

    /**
     * Records a figure the report cannot show because the file behind it is
     * not part of the project yet.
     */
    private void noteIfMissing(HospitalMetrics metrics, String filePath, String description) {
        File file = new File(filePath);
        if (!file.exists()) {
            metrics.addMissingSource(description);
        }
    }
}
