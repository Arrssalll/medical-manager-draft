/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import model.HospitalAsset;
import util.FileManager;
import util.IDGenerator;
import util.AuditLogger;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dhanj
 */
public class AssetService implements CrudService<HospitalAsset> {

    private static final String ASSETS_FILE = "data/hospitalAssets.txt";

    private HospitalAsset fromLine(String line) {
        String[] p = line.split("\\|");
        if (p.length < 5) return null;
        return new HospitalAsset(p[0], p[1], p[2], p[3], p[4]);
    }

    @Override
    public List<HospitalAsset> getAll() {
        List<HospitalAsset> assets = new ArrayList<>();
        for (String line : FileManager.readLines(ASSETS_FILE)) {
            HospitalAsset a = fromLine(line);
            if (a != null) assets.add(a);
        }
        return assets;
    }

    @Override
    public HospitalAsset getById(String id) {
        for (HospitalAsset a : getAll()) {
            if (a.getAssetId().equalsIgnoreCase(id)) return a;
        }
        return null;
    }

    public HospitalAsset createAsset(String type, String name, String location, String status) {
        String newId = IDGenerator.nextId(ASSETS_FILE, "HA", 3);
        HospitalAsset asset = new HospitalAsset(newId, type, name, location, status);
        FileManager.appendLine(ASSETS_FILE, asset.toFileLine());
        AuditLogger.getInstance().log("SYSTEM", "Created hospital asset " + newId + " (" + name + ")");
        return asset;
    }

    @Override
    public boolean add(HospitalAsset item) {
        if (item == null) return false;
        FileManager.appendLine(ASSETS_FILE, item.toFileLine());
        return true;
    }

    @Override
    public boolean update(String id, HospitalAsset updatedItem) {
        List<String> lines = FileManager.readLines(ASSETS_FILE);
        List<String> result = new ArrayList<>();
        boolean found = false;
        for (String line : lines) {
            String[] p = line.split("\\|");
            if (p.length >= 1 && p[0].equalsIgnoreCase(id)) {
                result.add(updatedItem.toFileLine());
                found = true;
            } else {
                result.add(line);
            }
        }
        if (found) {
            FileManager.writeLines(ASSETS_FILE, result);
            AuditLogger.getInstance().log("SYSTEM", "Updated hospital asset " + id);
        }
        return found;
    }

    @Override
    public boolean delete(String id) {
        List<String> lines = FileManager.readLines(ASSETS_FILE);
        List<String> result = new ArrayList<>();
        boolean found = false;
        for (String line : lines) {
            String[] p = line.split("\\|");
            if (p.length >= 1 && p[0].equalsIgnoreCase(id)) {
                found = true;
            } else {
                result.add(line);
            }
        }
        if (found) {
            FileManager.writeLines(ASSETS_FILE, result);
            AuditLogger.getInstance().log("SYSTEM", "Deleted hospital asset " + id);
        }
        return found;
    }
}
