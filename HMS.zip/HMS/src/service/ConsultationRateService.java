/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import model.ConsultationRate;
import util.FileManager;
import util.IDGenerator;
import util.AuditLogger;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author dhanj
 */
public class ConsultationRateService implements CrudService<ConsultationRate> {

    private static final String RATES_FILE = "data/consultationRates.txt";

    private ConsultationRate fromLine(String line) {
        String[] p = line.split("\\|");
        if (p.length < 4) return null;
        try {
            return new ConsultationRate(p[0], p[1], Double.parseDouble(p[2]), p[3]);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    public List<ConsultationRate> getAll() {
        List<ConsultationRate> rates = new ArrayList<>();
        for (String line : FileManager.readLines(RATES_FILE)) {
            ConsultationRate r = fromLine(line);
            if (r != null) rates.add(r);
        }
        return rates;
    }

    @Override
    public ConsultationRate getById(String id) {
        for (ConsultationRate r : getAll()) {
            if (r.getRateId().equalsIgnoreCase(id)) return r;
        }
        return null;
    }

    public ConsultationRate createRate(String departmentOrType, double amount, String status) {
        String newId = IDGenerator.nextId(RATES_FILE, "RATE", 3);
        ConsultationRate rate = new ConsultationRate(newId, departmentOrType, amount, status);
        FileManager.appendLine(RATES_FILE, rate.toFileLine());
        AuditLogger.getInstance().log("SYSTEM", "Created consultation rate " + newId);
        return rate;
    }

    @Override
    public boolean add(ConsultationRate item) {
        if (item == null) return false;
        FileManager.appendLine(RATES_FILE, item.toFileLine());
        return true;
    }

    @Override
    public boolean update(String id, ConsultationRate updatedItem) {
        List<String> lines = FileManager.readLines(RATES_FILE);
        List<String> result = new ArrayList<>();
        boolean found = false;
        for (String line : lines) {
            String[] p = line.split("\\|");
            if (p.length >= 1 && p[0].equalsIgnoreCase(id)) {
                result.add(updatedItem.toFileLine());
                found = true;
            } else {
                result.add(line);
            }
        }
        if (found) {
            FileManager.writeLines(RATES_FILE, result);
            AuditLogger.getInstance().log("SYSTEM", "Updated consultation rate " + id);
        }
        return found;
    }

    @Override
    public boolean delete(String id) {
        List<String> lines = FileManager.readLines(RATES_FILE);
        List<String> result = new ArrayList<>();
        boolean found = false;
        for (String line : lines) {
            String[] p = line.split("\\|");
            if (p.length >= 1 && p[0].equalsIgnoreCase(id)) {
                found = true;
            } else {
                result.add(line);
            }
        }
        if (found) {
            FileManager.writeLines(RATES_FILE, result);
            AuditLogger.getInstance().log("SYSTEM", "Deleted consultation rate " + id);
        }
        return found;
    }
}
