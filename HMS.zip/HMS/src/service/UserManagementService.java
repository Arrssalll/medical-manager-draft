/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import model.*;
import util.FileManager;
import util.IDGenerator;
import util.AuditLogger;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dhanj
 */
public class UserManagementService implements CrudService<User> {
 private static final String USERS_FILE = "data/users.txt";

    private User createUserFromRole(String id, String username, String password, String role, String status) {
        switch (role.toUpperCase()) {
            case "ADMIN":
                return new AdminStaff(id, username, password, status);
            case "MEDICAL_MANAGER":
                return new MedicalManager(id, "-", username, password, status);
            case "DOCTOR":
                return new Doctor(id, "-", username, password, "-", "-", "-", status);
            case "PATIENT":
                return new Patient(id, username, password, status);
            default:
                return null;
        }
    }

    @Override
    public List<User> getAll() {
        List<User> users = new ArrayList<>();
        for (String line : FileManager.readLines(USERS_FILE)) {
            String[] p = line.split("\\|");
            if (p.length < 5) continue;
            User u = createUserFromRole(p[0], p[1], p[2], p[3], p[4]);
            if (u != null) users.add(u);
        }
        return users;
    }

    @Override
    public User getById(String id) {
        for (User u : getAll()) {
            if (u.getUserId().equalsIgnoreCase(id)) return u;
        }
        return null;
    }

    public User getByUsername(String username) {
        for (User u : getAll()) {
            if (u.getUsername().equalsIgnoreCase(username)) return u;
        }
        return null;
    }

    public boolean isUsernameTaken(String username) {
        return getByUsername(username) != null;
    }

    public User createLoginAccount(String username, String password, String role, String status) {
        if (isUsernameTaken(username)) return null;

        String prefix;
        switch (role.toUpperCase()) {
            case "ADMIN": prefix = "A"; break;
            case "MEDICAL_MANAGER": prefix = "M"; break;
            case "DOCTOR": prefix = "D"; break;
            case "PATIENT": prefix = "P"; break;
            default: return null;
        }
        String newId = IDGenerator.nextId(USERS_FILE, prefix, 3);
        User newUser = createUserFromRole(newId, username, password, role.toUpperCase(), status);
        if (newUser == null) return null;

        FileManager.appendLine(USERS_FILE, newUser.toFileLine());
        AuditLogger.getInstance().log("SYSTEM", "Created login account " + newId + " (" + username + ", " + role + ")");
        return newUser;
    }

    @Override
    public boolean add(User item) {
        if (item == null || isUsernameTaken(item.getUsername())) return false;
        FileManager.appendLine(USERS_FILE, item.toFileLine());
        return true;
    }

    @Override
    public boolean update(String id, User updatedItem) {
        List<String> lines = FileManager.readLines(USERS_FILE);
        boolean found = false;
        List<String> result = new ArrayList<>();
        for (String line : lines) {
            String[] p = line.split("\\|");
            if (p.length >= 1 && p[0].equalsIgnoreCase(id)) {
                result.add(updatedItem.toFileLine());
                found = true;
            } else {
                result.add(line);
            }
        }
        if (found) {
            FileManager.writeLines(USERS_FILE, result);
            AuditLogger.getInstance().log("SYSTEM", "Updated user account " + id);
        }
        return found;
    }

    public boolean updateStatus(String id, String newStatus) {
        User u = getById(id);
        if (u == null) return false;
        u.setStatus(newStatus);
        return update(id, u);
    }

    public boolean resetPassword(String id, String newPassword) {
        User u = getById(id);
        if (u == null) return false;
        u.setPassword(newPassword);
        return update(id, u);
    }

    @Override
    public boolean delete(String id) {
        List<String> lines = FileManager.readLines(USERS_FILE);
        List<String> result = new ArrayList<>();
        boolean found = false;
        for (String line : lines) {
            String[] p = line.split("\\|");
            if (p.length >= 1 && p[0].equalsIgnoreCase(id)) {
                found = true;
            } else {
                result.add(line);
            }
        }
        if (found) {
            FileManager.writeLines(USERS_FILE, result);
            AuditLogger.getInstance().log("SYSTEM", "Deleted user account " + id);
        }
        return found;
    }   
    
}
